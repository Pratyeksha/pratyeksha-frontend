import './generate-posters.mjs';
