import './generate-posters.mjs';
