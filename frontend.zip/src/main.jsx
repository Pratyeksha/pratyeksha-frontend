import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import './index.css'
import App from './App.jsx'
import OperatorPortal from './OperatorPortal.jsx'
import KitchenView from './KitchenView.jsx'
import PratyekshaMasterAdmin from './PratyekshaMasterAdmin.jsx'
import Pratyeksha from './Pratyeksha.jsx'
import OwnerApp, { OwnerLauncher } from './OwnerApp.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BrowserRouter>
      <Routes>
        {/* 1. 🌐 Pratyeksha Landing Page */}
        <Route path="/landing" element={<Pratyeksha />} />

        {/* 2. Master Admin (SaaS Control) */}
        <Route path="/master-admin" element={<PratyekshaMasterAdmin />} />

        {/* 3. Kitchen Route */}
        <Route path="/kitchen/:tenantId" element={<KitchenView />} />

        {/* 4. Operator Portal Route */}
        <Route path="/operator" element={<OperatorPortal />} />

        {/* 5a. Owner App Launcher — this is what the installed PWA icon opens
               (web manifest start_url is "/owner/", with no tenant segment) */}
        <Route path="/owner" element={<OwnerLauncher />} />

        {/* 5b. Owner App Route (Live Dashboard, P&L, Inventory, Staff, etc.) */}
        <Route path="/owner/:tenantId/*" element={<OwnerApp />} />

        {/* 6. Customer Menu Route (Dynamic) */}
        {/* Must stay near the bottom — catches /:tenantId */}
        <Route path="/:tenantId" element={<App />} />

        {/* 7. Default Fallback → Landing Page */}
        <Route path="/" element={<Navigate to="/landing" replace />} />

      </Routes>
    </BrowserRouter>
  </StrictMode>
)