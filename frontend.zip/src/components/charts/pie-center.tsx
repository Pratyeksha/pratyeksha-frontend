"use client";

import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import {
  chartCenterContainerClassName,
  chartCenterLabelClassName,
  chartCenterValueClassName,
} from "./chart-center-typography";
import {
  ChartStatFlow,
  type ChartStatFlowFormat,
  defaultChartStatFlowFormat,
} from "./chart-stat-flow";
import { usePieHover, usePieStable } from "./pie-context";

export interface PieCenterProps {
  /** Label shown below the value. Default: "Total" when not hovering */
  defaultLabel?: string;
  /** Format options for NumberFlow. Default: standard notation */
  formatOptions?: ChartStatFlowFormat;
  /**
   * Custom render function for complete control over center content.
   * Called both at rest and while a slice is hovered: at rest `value` is the
   * total, `label` is `defaultLabel`, `isHovered` is false and `data` has no
   * `color`/`fill`. Branch on `isHovered` to style the two states.
   */
  children?: (props: {
    value: number;
    label: string;
    isHovered: boolean;
    data: { label: string; value: number; color?: string; fill?: string };
  }) => ReactNode;
  /** Additional class name for the container */
  className?: string;
  /** Class name for the value text. Scales with center size via container queries. */
  valueClassName?: string;
  /** Class name for the label text. Scales with center size via container queries. */
  labelClassName?: string;
  /** Prefix to show before the number (e.g., "$") */
  prefix?: string;
  /** Suffix to show after the number (e.g., "%"). Defaults to "%" in percent mode */
  suffix?: string;
  /**
   * `"value"` (default) shows the raw value. `"percent"` shows the hovered
   * slice's share of the total, and 100 at rest — a gauge-style readout.
   */
  valueDisplay?: "value" | "percent";
}

/**
 * PieCenter displays content in the center of a donut/pie chart.
 *
 * This component renders as pure HTML (not inside SVG foreignObject) to avoid
 * Safari's WebKit bug #23113 where HTML content with CSS transforms/opacity
 * inside foreignObject renders at incorrect positions.
 *
 * The parent PieChart uses CSS Grid stacking to overlay this HTML content
 * on top of the SVG slices.
 */
export function PieCenter({
  defaultLabel = "Total",
  formatOptions = defaultChartStatFlowFormat,
  children,
  className = "",
  valueClassName = chartCenterValueClassName,
  labelClassName = chartCenterLabelClassName,
  prefix,
  suffix: suffixProp,
  valueDisplay = "value",
}: PieCenterProps) {
  const { data, totalValue, innerRadius, geometryScrubbing } = usePieStable();
  const { hoveredIndex } = usePieHover();

  const effectiveHoveredIndex = geometryScrubbing ? null : hoveredIndex;
  const hoveredData =
    effectiveHoveredIndex === null ? null : data[effectiveHoveredIndex];
  const percentMode = valueDisplay === "percent";
  const suffix = suffixProp ?? (percentMode ? "%" : undefined);
  const rawValue = hoveredData ? hoveredData.value : totalValue;
  const share = totalValue > 0 ? (rawValue / totalValue) * 100 : 0;
  const displayValue = percentMode ? Math.round(share) : rawValue;
  const displayLabel = hoveredData ? hoveredData.label : defaultLabel;

  // Calculate center area size based on inner radius
  // Leave some padding so text doesn't touch the inner edge
  const centerSize = innerRadius * 2 - 16;

  // Don't render if there's no inner radius (solid pie, not donut)
  if (innerRadius <= 0) {
    return null;
  }

  // If custom render function is provided, use it
  if (children) {
    return (
      <div
        className={cn(
          chartCenterContainerClassName,
          "flex items-center justify-center",
          className
        )}
        style={{ width: centerSize, height: centerSize }}
      >
        {children({
          value: displayValue,
          label: displayLabel,
          isHovered: Boolean(hoveredData),
          data: hoveredData ?? { label: defaultLabel, value: totalValue },
        })}
      </div>
    );
  }

  // Default center content with NumberFlow animations
  // Now renders as pure HTML, avoiding Safari's foreignObject bugs
  return (
    <div
      className={cn(
        chartCenterContainerClassName,
        "flex flex-col items-center justify-center text-center",
        className
      )}
      style={{ width: centerSize, height: centerSize }}
    >
      <ChartStatFlow
        formatOptions={formatOptions}
        label={displayLabel}
        labelClassName={labelClassName}
        prefix={prefix}
        suffix={suffix}
        value={displayValue}
        valueClassName={valueClassName}
      />
    </div>
  );
}

PieCenter.displayName = "PieCenter";

export default PieCenter;
