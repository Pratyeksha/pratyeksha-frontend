"use client";

import { useId, useLayoutEffect, useMemo, useRef } from "react";
import type { AreaProps } from "./area";
import {
  evenlySpacedLabelIndices,
  layoutAreaValueLabels,
  resolveAreaValueLabelCount,
  resolveSharedAreaValueLabelCount,
} from "./area-value-label-layout";
import { chartCssVars, useChartStable } from "./chart-context";
import { valueLabelFmt } from "./chart-formatters";
import {
  fadeGradientStops,
  resolveFadeSides,
  viewportFadeGradientAttrs,
} from "./fade-edges";

/** One final layer keeps later area fills from painting over earlier labels. */
export function AreaValueLabels({ series }: { series: AreaProps[] }) {
  const {
    data,
    xScale,
    xAccessor,
    yScale,
    yScales,
    innerWidth,
    innerHeight,
    chartPhase,
  } = useChartStable();
  const layerRef = useRef<SVGGElement>(null);
  const id = useId();
  const labels = useMemo(() => {
    if (!["revealing", "ready", "exitingReady"].includes(chartPhase)) {
      return [];
    }
    const visible = data
      .map((datum, index) => ({ datum, index, x: xScale(xAccessor(datum)) }))
      .filter(({ x }) => Number.isFinite(x) && x >= 0 && x <= innerWidth);
    const visibleSeries = series
      .map((area, seriesIndex) => ({
        area,
        seriesIndex,
        points: visible.filter(
          ({ datum }) =>
            typeof datum[area.dataKey] === "number" &&
            Number.isFinite(datum[area.dataKey])
        ),
      }))
      .filter(({ area }) => area.showValue);
    const counts = visibleSeries.map(({ area, points }) =>
      resolveAreaValueLabelCount(
        points.length,
        innerWidth,
        area.valueLabelMinCount,
        area.valueLabelMaxCount
      )
    );
    const sharedCount = resolveSharedAreaValueLabelCount(counts);
    return visibleSeries.flatMap(({ area, seriesIndex, points }, i) => {
      // Series that resolve to 0 (e.g. `valueLabelMaxCount={0}`) stay hidden;
      // the rest share the smallest non-zero count so labels line up.
      const count = Math.min(sharedCount, counts[i] ?? 0);
      if (count === 0) {
        return [];
      }
      const indices = evenlySpacedLabelIndices(points.length, count);
      return indices.flatMap((position) => {
        const point = position == null ? undefined : points[position];
        if (!point) {
          return [];
        }
        const { datum, index, x } = point;
        const value = datum[area.dataKey] as number;
        const scale = yScales[String(area.yAxisId ?? "left")] ?? yScale;
        const y = scale(value);
        if (!Number.isFinite(y)) {
          return [];
        }
        return [
          {
            index,
            seriesIndex,
            x,
            y,
            text: area.valueLabelFormatter?.(value) ?? valueLabelFmt(value),
          },
        ];
      });
    });
  }, [
    data,
    series,
    xScale,
    xAccessor,
    yScale,
    yScales,
    innerWidth,
    chartPhase,
  ]);

  useLayoutEffect(() => {
    const layer = layerRef.current;
    if (!layer) {
      return;
    }
    let active = true;
    const arrange = () => {
      if (!active) {
        return;
      }
      const elements = Array.from(layer.querySelectorAll("text"));
      const boxes = labels.map((label, index) => {
        const bounds = elements[index]?.getBBox();
        return {
          ...label,
          width: bounds?.width ?? 0,
          height: bounds?.height ?? 0,
        };
      });
      for (const element of elements) {
        element.style.visibility = "hidden";
      }
      for (const box of layoutAreaValueLabels(boxes, innerWidth, innerHeight)) {
        const element = elements[box.source];
        if (!element) {
          continue;
        }
        // Measure at the origin so font ascent, Persian digits and custom formats are respected.
        const bounds = element.getBBox();
        element.setAttribute(
          "transform",
          `translate(${box.x - bounds.x - bounds.width / 2}, ${box.y - bounds.y - bounds.height / 2})`
        );
        element.style.visibility = "visible";
      }
    };
    arrange();
    // Font loading changes Persian glyph widths; remeasure before deciding collisions.
    document.fonts.ready.then(arrange);
    document.fonts.addEventListener("loadingdone", arrange);
    return () => {
      active = false;
      document.fonts.removeEventListener("loadingdone", arrange);
    };
  }, [labels, innerWidth, innerHeight]);

  // Labels are opt-in: charts without `showValue` render no extra layer.
  if (!series.some((area) => area.showValue)) {
    return null;
  }

  return (
    <g pointerEvents="none" ref={layerRef}>
      <defs>
        {series.map(
          (area, index) =>
            area.fadeValueLabels && (
              <g key={area.dataKey}>
                <linearGradient
                  id={`${id}-${index}`}
                  {...viewportFadeGradientAttrs(innerWidth)}
                >
                  {fadeGradientStops(
                    resolveFadeSides(area.fadeEdges ?? false)
                  ).map((stop) => (
                    <stop
                      key={stop.offset}
                      offset={stop.offset}
                      stopColor="white"
                      stopOpacity={stop.opacity}
                    />
                  ))}
                </linearGradient>
                <mask
                  height={innerHeight}
                  id={`${id}-${index}-mask`}
                  maskUnits="userSpaceOnUse"
                  width={innerWidth}
                  x={0}
                  y={0}
                >
                  <rect
                    fill={`url(#${id}-${index})`}
                    height={innerHeight}
                    width={innerWidth}
                  />
                </mask>
              </g>
            )
        )}
      </defs>
      {labels.map((label) => {
        const area = series[label.seriesIndex];
        if (!area) {
          return null;
        }
        return (
          <g
            key={`${label.seriesIndex}-${label.index}`}
            mask={
              area.fadeValueLabels
                ? `url(#${id}-${label.seriesIndex}-mask)`
                : undefined
            }
          >
            <text
              className="font-medium text-[10px]"
              fill={
                area.valueLabelColor ??
                area.stroke ??
                (area.fill?.startsWith("url(") ? undefined : area.fill) ??
                chartCssVars.linePrimary
              }
              style={{
                visibility: "hidden",
                paintOrder: "stroke",
                stroke: "var(--background)",
                strokeWidth: 3,
              }}
              x={0}
              y={0}
            >
              {label.text}
            </text>
          </g>
        );
      })}
    </g>
  );
}
