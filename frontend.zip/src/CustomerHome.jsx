import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import axios from 'axios';
import {
  Coffee, UtensilsCrossed, Search,  ChevronRight, MapPin, Wifi, Sparkles, X, Tag,
  Heart, ScanLine, Shuffle, ShoppingBag, CalendarCheck, Clock, LayoutGrid, RotateCcw,
  Navigation, Map as MapIcon, List as ListIcon, Copy, Share2, Crosshair, ExternalLink, Check, ArrowUp, ArrowUpDown, History, Phone, WifiOff, Leaf, Star,
  CalendarClock, Armchair , Mic}  from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLocation, useNavigate } from 'react-router-dom';
import PwaInstallButton from './PwaInstallButton.jsx';
import { fx, PrefsMenu, CustomerExtras, TimeGreeting, useBackClose } from './customerFx.jsx';
import SpoonForkIcon from './SpoonForkIcon.jsx';
import OffersExplorer from './OffersExplorer.jsx';

import API_BASE_URL from './apiBase.js';
import { ensureModelViewer } from './modelViewer.js';

const BASE_URL = API_BASE_URL;
const logo = '/pratyeksha-logo.png';
const GOLD = '#d3bfa2';
const PAGE = 8;
const SORT_KEY = 'px_home_sort';
const SEARCHES_KEY = 'px_home_searches';
/** First word of the guest's remembered name (saved per outlet by the ordering app). Display only; nothing is sent anywhere. */
const readGuestFirstName = () => {
  try {
    for (let i = 0; i < localStorage.length; i += 1) {
      const k = localStorage.key(i);
      if (!k || !k.startsWith('pratyeksha_customer_history_')) continue;
      const v = JSON.parse(localStorage.getItem(k) || 'null');
      const first = String(v?.name || '').trim().split(/\s+/)[0];
      if (first && first.toLowerCase() !== 'guest') return first.charAt(0).toUpperCase() + first.slice(1);
    }
  } catch { /* storage unavailable */ }
  return '';
};
const FAV_KEY = 'px_home_favs';
const LANG_KEY = 'px_home_lang';
const FILTERS_KEY = 'px_home_filters';
const CACHE_KEY = 'px_home_cache';

/* Marathi / English strings for the directory (the guest's choice is remembered). */
const L = {
  en: {
    heroLive: 'places live now', morning: 'Good morning', afternoon: 'Good afternoon', evening: 'Good evening', search: 'Search', all: 'All', cafe: 'Café', dine: 'Dine',
    pickup: 'Pickup', reservation: 'Reserve', waitlist: 'Waitlist', saved: 'Saved', offers: 'Offers', veg: 'Pure veg', nearMe: 'Near me',
    allAreas: 'All areas', place: 'place', places: 'places', nearest: ' · nearest first', list: 'List', map: 'Map', nothing: 'Nothing found', nothingHint: 'Try “chai”, “misal” or a nearby area name.', madeWith: 'Made with {h} for hungry people',
    welcomeBack: 'Welcome back', pickUp: 'Open menu', dismiss: 'Dismiss',
    clear: 'Clear filters', retry: 'Retry', more: 'more', recent: 'Recent', clearRecent: 'Clear', saveHint: 'Tap the heart on a place to keep it here. Your go-to spots, one tap away.',
    offlineCached: "Couldn't refresh — showing your last saved list", offline: "You're offline", directions: 'Directions', openMenu: 'Open menu', call: 'Call',
    loadFail: 'Unable to load restaurants.', locDenied: 'Allow location access to sort by distance', locTimeout: 'Could not get your location in time — try again',
    locNA: 'Location is not available on this device', locBusy: 'Location unavailable right now', finding: 'Finding you…', inArea: 'in',
    featured: 'Featured', isNew: 'New',
    didYouMean: 'Did you mean', voice: 'Voice search', listening: 'Listening…', servedAt: 'at',
    reserveNow: 'Reserve a table', joinWaitlist: 'Join waitlist', orderPickup: 'Order pickup', share: 'Share', copy: 'Copy', googleMaps: 'Google Maps',
    loadingMap: 'Loading map', noLocation: 'Location not added yet', surprise: 'Surprise me', backToTop: 'Back to top', addrCopied: 'Address copied', copyNA: 'Copy not available',
    nearLandmark: 'Near', validTill: 'Valid till', minBill: 'Min bill', useCode: 'Code', straightLine: 'in a straight line', away: 'away', featuredRail: 'Featured places', statOffers: 'live offers', statPickup: 'offer pickup', statReserve: 'take reservations',
    howTitle: 'How it works', how1t: 'Find', how1: 'Browse cafés & restaurants near you', how2t: 'Order', how2: 'Scan the table QR to order or reserve — no app to install',
    how3t: 'Enjoy', how3: 'Track your order and ask for the bill from your phone', hide: 'Hide', shareView: 'Share this list', linkCopied: 'Link copied',
    ownerTitle: 'Own a café or restaurant?', ownerBody: 'Get your own QR menu, table ordering, reservations and live offers — listed here for every guest.', ownerBtn: 'Get listed',
    hoursTitle: 'Opening hours', sortRec: 'Recommended', sortAz: 'A – Z', sortOffers: 'Most offers', sortSaved: 'Saved first', sort: 'Sort',
    updated: 'Updated', justNow: 'just now', minAgo: 'min ago', hrAgo: 'h ago', dayAgo: 'd ago', refresh: 'Refresh', refreshing: 'Refreshing…',
    pullHint: 'Pull to refresh', releaseHint: 'Release to refresh', suggestions: 'Suggestions', sugArea: 'Area',
    openNow: 'Open now', closesAt: 'closes', closingSoon: 'Closing soon', closedNow: 'Closed', opensAt: 'opens', tomorrow: 'tomorrow', tempClosed: 'Temporarily closed',
    opensSoon: 'Opens in {n} min', statOpen: 'open now', loadingList: 'Finding good food near you…',
    searchPh: 'Search places, areas, dishes…', searchPhShort: 'Search…', browseMenu: 'Browse by menu', serves: 'Serves', menuCategory: 'Category', tryMenu: 'Try a menu category', sugCategory: 'Category', sugDish: 'Dish',
    open24: 'Open 24 hours', monFri: 'Mon–Fri', satSun: 'Sat–Sun', closedOn: 'Closed on', minShort: 'min', days: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
  },
  mr: {
    heroLive: 'ठिकाणे आता सुरू', morning: 'शुभ प्रभात', afternoon: 'शुभ दुपार', evening: 'शुभ संध्याकाळ', search: 'शोधा', all: 'सर्व', cafe: 'कॅफे', dine: 'डाइन',
    pickup: 'पिकअप', reservation: 'आरक्षण', waitlist: 'प्रतीक्षा', saved: 'आवडते', offers: 'ऑफर्स', veg: 'शुद्ध शाकाहारी', nearMe: 'जवळ',
    allAreas: 'सर्व भाग', place: 'ठिकाण', places: 'ठिकाणे', nearest: ' · सर्वात जवळचे आधी', list: 'यादी', map: 'नकाशा', nothing: 'काहीही सापडले नाही', nothingHint: '“चहा”, “मिसळ” किंवा जवळचा भाग शोधून पहा.', madeWith: 'भुकेल्या जिवांसाठी {h} ने बनवले',
    welcomeBack: 'पुन्हा स्वागत', pickUp: 'मेनू उघडा', dismiss: 'बंद करा',
    clear: 'फिल्टर काढा', retry: 'पुन्हा प्रयत्न', more: 'आणखी', recent: 'अलीकडील', clearRecent: 'पुसा', saveHint: 'आवडते ठिकाण इथे ठेवण्यासाठी हृदयावर टॅप करा. तुमची नेहमीची ठिकाणे, एका टॅपवर.',
    offlineCached: 'रिफ्रेश झाले नाही — शेवटची जतन केलेली यादी दाखवत आहे', offline: 'तुम्ही ऑफलाइन आहात', directions: 'दिशा', openMenu: 'मेनू उघडा', call: 'कॉल',
    loadFail: 'रेस्टॉरंट लोड करता आले नाहीत.', locDenied: 'अंतरानुसार क्रमवारीसाठी लोकेशनची परवानगी द्या', locTimeout: 'लोकेशन वेळेत मिळाले नाही — पुन्हा प्रयत्न करा',
    locNA: 'या डिव्हाइसवर लोकेशन उपलब्ध नाही', locBusy: 'लोकेशन सध्या उपलब्ध नाही', finding: 'तुमचे लोकेशन शोधत आहे…', inArea: 'येथे',
    featured: 'विशेष', isNew: 'नवीन',
    didYouMean: 'तुम्हाला हे म्हणायचे आहे का', voice: 'आवाजाने शोधा', listening: 'ऐकत आहे…', servedAt: 'येथे',
    reserveNow: 'टेबल आरक्षित करा', joinWaitlist: 'प्रतीक्षा यादीत सामील व्हा', orderPickup: 'पिकअप ऑर्डर करा', share: 'शेअर करा', copy: 'कॉपी', googleMaps: 'गुगल मॅप्स',
    loadingMap: 'नकाशा लोड होत आहे', noLocation: 'स्थान अजून जोडलेले नाही', surprise: 'काहीतरी नवीन सुचवा', backToTop: 'वर जा', addrCopied: 'पत्ता कॉपी केला', copyNA: 'कॉपी उपलब्ध नाही',
    nearLandmark: 'जवळ', validTill: 'वैध', minBill: 'किमान बिल', useCode: 'कोड', straightLine: 'सरळ रेषेत', away: 'दूर', featuredRail: 'विशेष ठिकाणे', statOffers: 'चालू ऑफर्स', statPickup: 'पिकअप देतात', statReserve: 'आरक्षण घेतात',
    howTitle: 'हे कसे चालते', how1t: 'शोधा', how1: 'तुमच्या जवळची कॅफे आणि रेस्टॉरंट्स पाहा', how2t: 'ऑर्डर करा', how2: 'टेबलचा QR स्कॅन करून ऑर्डर किंवा आरक्षण करा — अ‍ॅप नको',
    how3t: 'आनंद घ्या', how3: 'ऑर्डर ट्रॅक करा आणि फोनवरूनच बिल मागवा', hide: 'लपवा', shareView: 'ही यादी शेअर करा', linkCopied: 'लिंक कॉपी झाली',
    ownerTitle: 'तुमचे कॅफे किंवा रेस्टॉरंट आहे का?', ownerBody: 'स्वतःचा QR मेनू, टेबल ऑर्डरिंग, आरक्षण आणि लाइव्ह ऑफर्स मिळवा — प्रत्येक पाहुण्यासाठी येथे सूचीबद्ध.', ownerBtn: 'सूचीत या',
    hoursTitle: 'वेळ', sortRec: 'शिफारस केलेले', sortAz: 'अ – ज्ञ', sortOffers: 'सर्वाधिक ऑफर्स', sortSaved: 'आवडते आधी', sort: 'क्रमवारी',
    updated: 'अपडेट', justNow: 'आत्ताच', minAgo: 'मि. पूर्वी', hrAgo: 'तासांपूर्वी', dayAgo: 'दिवसांपूर्वी', refresh: 'रिफ्रेश', refreshing: 'रिफ्रेश होत आहे…',
    pullHint: 'रिफ्रेश करण्यासाठी खाली ओढा', releaseHint: 'रिफ्रेश करण्यासाठी सोडा', suggestions: 'सूचना', sugArea: 'भाग',
    openNow: 'आता उघडे', closesAt: 'बंद होईल', closingSoon: 'लवकरच बंद', closedNow: 'बंद', opensAt: 'उघडेल', tomorrow: 'उद्या', tempClosed: 'तात्पुरते बंद',
    opensSoon: '{n} मि. मध्ये उघडेल', statOpen: 'आता उघडे', loadingList: 'जवळचे चविष्ट ठिकाण शोधत आहे…',
    searchPh: 'ठिकाण, भाग, पदार्थ शोधा…', searchPhShort: 'शोधा…', browseMenu: 'मेनूनुसार शोधा', serves: 'उपलब्ध', menuCategory: 'श्रेणी', tryMenu: 'मेनू श्रेणी वापरून पहा', sugCategory: 'श्रेणी', sugDish: 'पदार्थ',
    open24: '२४ तास उघडे', monFri: 'सोम–शुक्र', satSun: 'शनि–रवि', closedOn: 'बंद', minShort: 'मि.', days: ['रवि', 'सोम', 'मंगळ', 'बुध', 'गुरु', 'शुक्र', 'शनि'],
  },
};
const readJson = (key, fallback) => { try { const v = JSON.parse(localStorage.getItem(key) || 'null'); return v ?? fallback; } catch { return fallback; } };
const writeJson = (key, value) => { try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* ignore */ } };
/* Server data is untrusted shape-wise: keep only outlets with an id, drop duplicates, make activeOffers always an array. */
const normalizeTenants = (raw) => {
  if (!Array.isArray(raw)) return [];
  const seen = new Set();
  const out = [];
  for (const t of raw) {
    if (!t || typeof t !== 'object' || !t.tenantId || seen.has(t.tenantId)) continue;
    seen.add(t.tenantId);
    out.push({ ...t, activeOffers: Array.isArray(t.activeOffers) ? t.activeOffers.filter((o) => o && typeof o === 'object') : [] });
  }
  return out;
};
const RECENT_KEY = 'px_home_recent';
const AREA_KEY = 'px_home_area';

/* localStorage can throw (private mode / blocked) — the page must work without it. */
const readList = (key) => {
  try {
    const v = JSON.parse(localStorage.getItem(key) || '[]');
    return Array.isArray(v) ? v.filter((x) => typeof x === 'string') : [];
  } catch { return []; }
};
const writeList = (key, list) => { try { localStorage.setItem(key, JSON.stringify(list)); } catch { /* ignore */ } };

const typeOf = (t) => String(t?.businessType || 'Restaurant').trim().toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
const isCafe = (t) => typeOf(t) === 'cafe' || /\bcaf[eé]s?\b|\bcoffee\b/i.test(String(t?.name || '')); // word match: "Cafeteria Grill" is not a café
const offerValue = (o) => {
  const v = Number(o?.value);
  if (o?.type === 'percent_off') return Number.isFinite(v) ? `${v}% OFF` : 'OFFER';
  if (o?.type === 'fixed_off') return Number.isFinite(v) ? `₹${v} OFF` : 'OFFER';
  if (o?.type === 'free_item') return `FREE ${o.freeItem || 'ITEM'}`;
  return 'HAPPY HOUR';
};
/* "Valid till 30 Oct - Min bill 500 - Code SAVE10": what a diner needs to know before walking in. */
const offerTerms = (o, tr) => {
  const bits = [];
  const d = o?.expiresAt ? new Date(o.expiresAt) : null;
  if (d && !Number.isNaN(d.getTime())) bits.push(`${tr.validTill} ${d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', timeZone: 'Asia/Kolkata' })}`);
  const mb = Number(o?.minOrder);
  if (Number.isFinite(mb) && mb > 0) bits.push(`${tr.minBill} ${mb}`);
  if (o?.code) bits.push(`${tr.useCode} ${String(o.code).toUpperCase()}`);
  return bits.join(' \u00b7 ');
};
/* The most attractive live offer of an outlet (largest % off first) - shown as the card headline. */
const offerRank = (o) => (o?.type === 'percent_off' ? Number(o.value) || 0 : o?.type === 'fixed_off' ? 1 : 0.5);
const bestOffer = (t) => {
  const list = Array.isArray(t?.activeOffers) ? t.activeOffers : [];
  return list.length ? list.reduce((m, o) => (offerRank(o) > offerRank(m) ? o : m), list[0]) : null;
};
/* Owner-controlled placement: set `featured: true` on a tenant (or config.featured) to pin it first and show it in the Featured row. */
const isFeatured = (t) => t?.featured === true || t?.config?.featured === true;
const isNew = (t) => {
  const d = new Date(t?.createdAt).getTime();
  return Number.isFinite(d) && d <= Date.now() + 864e5 && Date.now() - d < 30 * 864e5;
};
/* Optional "Own a café or restaurant?" card for owners - set to a WhatsApp / contact link (https:, mailto: or tel:). Empty = hidden. */
const OWNER_CTA_URL = '';
const HOW_KEY = 'px_home_how';
const MENU_CACHE_KEY = 'px_home_menu_v1';

/* ── Menu search: the server publishes each outlet's categories and top dishes (GET /tenants/menu-index) so the search bar can answer
   "biryani", "cold coffee" or a Marathi dish name with the outlets that serve it. ── */
const normQ = (v) => String(v || '').normalize('NFKC').toLowerCase().replace(/\s+/g, ' ').trim();
function buildMenuLookup(raw) {
  const map = new Map();
  const cats = new Map();
  for (const [id, e] of Object.entries(raw?.tenants || {})) {
    if (!e || typeof e !== 'object') continue;
    const c = [...(Array.isArray(e.c) ? e.c : []), ...(Array.isArray(e.cm) ? e.cm : [])].filter(Boolean);
    const d = [...(Array.isArray(e.d) ? e.d : []), ...(Array.isArray(e.dm) ? e.dm : [])].filter(Boolean);
    map.set(id, { cats: c.map((x) => ({ raw: x, lc: normQ(x) })), dishes: d.map((x) => ({ raw: x, lc: normQ(x) })) });
    const seen = new Set();
    for (const x of Array.isArray(e.c) ? e.c : []) {
      const k = normQ(x);
      if (!k || seen.has(k)) continue;
      seen.add(k);
      const cur = cats.get(k) || { label: x, n: 0 };
      cur.n += 1;
      cats.set(k, cur);
    }
  }
  const top = [...cats.values()].sort((a, b) => b.n - a.n || a.label.localeCompare(b.label)).slice(0, 10);
  return { map, top };
}
const uniqList = (arr) => [...new Set(arr)];
/* Why does this outlet match the typed text? Priority: name > menu category > dish > area. A multi-word search
   ("veg biryani rajarampuri") matches when every word hits something; the whole phrase is tried first ("cold coffee"). */
function matchWhy(t, q, menu) {
  if (!q) return null;
  const name = normQ(t.name);
  const addr = normQ(`${t.address?.area || ''} ${t.address?.city || ''} ${t.address?.landmark || ''} ${t.address?.street || ''}`);
  const m = menu?.map.get(t.tenantId);
  const hitsFor = (needle) => ({
    name: name.includes(needle),
    area: addr.includes(needle),
    category: m ? m.cats.filter((c) => c.lc.includes(needle)).map((c) => c.raw) : [],
    dish: m ? m.dishes.filter((d) => d.lc.includes(needle)).map((d) => d.raw) : [],
  });
  const any = (h) => h.name || h.area || h.category.length > 0 || h.dish.length > 0;
  let h = hitsFor(q);
  if (!any(h)) {
    const words = q.split(' ').filter(Boolean);
    if (words.length < 2) return null;
    const parts = words.map(hitsFor);
    if (!parts.every(any)) return null;
    h = { name: parts.some((p) => p.name), area: parts.some((p) => p.area), category: uniqList(parts.flatMap((p) => p.category)), dish: uniqList(parts.flatMap((p) => p.dish)) };
  }
  const w = h.name ? 'name' : h.category.length ? 'category' : h.dish.length ? 'dish' : 'area';
  return { w, name: h.name, area: h.area, category: uniqList(h.category).slice(0, 2), dish: uniqList(h.dish).slice(0, 3) };
}

/* ── Loading skeleton: the same geometry as the real list (stats line, count row, 2-up card grid) so nothing jumps when data lands ── */
const SR_ONLY = { position: 'absolute', width: 1, height: 1, margin: -1, padding: 0, overflow: 'hidden', clip: 'rect(0 0 0 0)', whiteSpace: 'nowrap', border: 0 };
const Sk = ({ w, h, r = 8, d = 0, style }) => <span className="pxh-sk" style={{ display: 'block', width: w, height: h, borderRadius: r, '--d': `${d}s`, ...style }} />;
function SkeletonCard({ i }) {
  const d = (i % 6) * 0.12;
  return (
    <div className="pxh-card pxh-sk-card pxh-sk-in" style={{ animationDelay: `${Math.min(i, 8) * 0.05}s` }} aria-hidden="true">
      <div style={{ padding: '14px 14px 13px' }}>
        <Sk w={52} h={52} r={16} d={d} />
        <Sk w={`${58 + ((i * 13) % 26)}%`} h={14} r={7} d={d} style={{ marginTop: 12, marginBottom: 3 }} />
        <div style={{ marginTop: 4, height: 14, display: 'flex', alignItems: 'center' }}><Sk w={`${34 + ((i * 11) % 22)}%`} h={10} r={5} d={d} /></div>
        <Sk w={78} h={19} r={10} d={d} style={{ marginTop: 8 }} />
        <div style={{ marginTop: 11, minHeight: 24, display: 'flex', alignItems: 'center', gap: 9 }}>
          <Sk w={13} h={13} r={7} d={d} /><Sk w={13} h={13} r={7} d={d} /><Sk w={13} h={13} r={7} d={d} />
        </div>
      </div>
      <span className="pxh-sk" style={{ position: 'absolute', top: 10, right: 10, width: 30, height: 30, borderRadius: '50%', '--d': `${d}s` }} />
    </div>
  );
}
function ListSkeleton({ label }) {
  return (
    <div role="status" aria-busy="true" aria-live="polite">
      <span style={SR_ONLY}>{label}</span>
      <div aria-hidden="true">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10, margin: '0 0 12px', minHeight: 40 }}>
          <Sk w={112} h={12} r={6} />
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Sk w={104} h={34} r={13} d={0.1} />
            <Sk w={122} h={40} r={13} d={0.2} />
          </div>
        </div>
        <div className="pxh-grid">{Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} i={i} />)}</div>
      </div>
    </div>
  );
}

/* Dialog accessibility: move focus into the dialog, keep Tab inside it, and give focus back to the opener on close. */
const FOCUSABLE = 'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';
function useFocusTrap(active, ref) {
  useEffect(() => {
    if (!active) return undefined;
    const opener = document.activeElement;
    const node = ref.current;
    const items = () => (node ? [...node.querySelectorAll(FOCUSABLE)].filter((el) => el.getClientRects().length > 0) : []);
    const first = items()[0] || node;
    if (first && typeof first.focus === 'function') first.focus({ preventScroll: true });
    const onKey = (e) => {
      if (e.key !== 'Tab' || !node) return;
      const list = items();
      if (!list.length) { e.preventDefault(); node.focus(); return; }
      const a = list[0];
      const z = list[list.length - 1];
      const cur = document.activeElement;
      if (!node.contains(cur)) { e.preventDefault(); a.focus(); }
      else if (e.shiftKey && cur === a) { e.preventDefault(); z.focus(); }
      else if (!e.shiftKey && cur === z) { e.preventDefault(); a.focus(); }
    };
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('keydown', onKey);
      if (opener && opener.isConnected && typeof opener.focus === 'function') opener.focus({ preventScroll: true });
    };
  }, [active, ref]);
}

/* "Updated 3 min ago" */
const fmtAgo = (ts, tr) => {
  const sec = Math.max(0, (Date.now() - ts) / 1000);
  if (sec < 45) return tr.justNow;
  const m = Math.round(sec / 60);
  if (m < 60) return `${m} ${tr.minAgo}`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} ${tr.hrAgo}`;
  return `${Math.round(h / 24)} ${tr.dayAgo}`;
};

/* The audit tool is internal: it only works in dev builds or when the site is built with VITE_ENABLE_LISTING_AUDIT=true. */
const AUDIT_ENABLED = import.meta.env.DEV || import.meta.env.VITE_ENABLE_LISTING_AUDIT === 'true';
/* Listing audit (open the page with ?audit=1): what is still missing on an outlet's public listing. Internal tool, English only. */
const listingGaps = (t) => {
  const g = [];
  if (!isCafe(t) && !t?.branding?.logoUrl) g.push('No logo');
  if (!areaOf(t)) g.push('No area');
  if (!String(t?.address?.street || '').trim()) g.push('No street');
  if (!hasCoords(t)) g.push('No map pin');
  if (String(t?.contact || t?.phone || '').replace(/\D/g, '').length < 7) g.push('No phone');
  if (!t?.hours) g.push('Hours hidden');
  return g;
};

/* ── Opening hours. The server sends `hours` only for outlets whose owner turned on "Show on guest directory"; everything is IST. ── */
const toMin = (str) => {
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(str || '').trim());
  if (!m) return null;
  const h = Number(m[1]);
  const mi = Number(m[2]);
  return h < 24 && mi < 60 ? h * 60 + mi : null;
};
const hoursWindow = (hours, day) => {
  if (Array.isArray(hours?.closedDays) && hours.closedDays.includes(day)) return null;
  const blk = day >= 1 && day <= 5 ? hours?.weekday : hours?.weekend;
  const o = toMin(blk?.open);
  const c = toMin(blk?.close);
  return o == null || c == null ? null : { o, c };
};
/* Returns null when we can't say (no / unreadable hours) - the page never claims "Closed" without data. */
const openStatus = (hours, nowMs = Date.now()) => {
  if (!hours || typeof hours !== 'object') return null;
  if (hours.temporarilyClosed === true) return { state: 'closed', temp: true };
  const ist = new Date(nowMs + 330 * 60000);
  const day = ist.getUTCDay();
  const m = ist.getUTCHours() * 60 + ist.getUTCMinutes();
  const week = [0, 1, 2, 3, 4, 5, 6].map((d) => hoursWindow(hours, d));
  if (!week.some(Boolean)) return Array.isArray(hours.closedDays) && hours.closedDays.length >= 7 ? { state: 'closed' } : null;
  const today = week[day];
  const yday = week[(day + 6) % 7];
  if (today) {
    const { o, c } = today;
    if (o === c) return { state: 'open', allDay: true };
    if (o < c && m >= o && m < c) return { state: 'open', closesAt: c, minsLeft: c - m };
    if (o > c && m >= o) return { state: 'open', closesAt: c, minsLeft: 1440 - m + c }; // overnight window that started today
  }
  if (yday && yday.o > yday.c && m < yday.c) return { state: 'open', closesAt: yday.c, minsLeft: yday.c - m }; // yesterday's overnight window still running
  if (today && m < today.o) return { state: 'closed', opensAt: today.o, dayOffset: 0, opensDay: day, minsToOpen: today.o - m };
  for (let d = 1; d <= 7; d++) {
    const w = week[(day + d) % 7];
    if (w) return { state: 'closed', opensAt: w.o, dayOffset: d, opensDay: (day + d) % 7 };
  }
  return { state: 'closed' };
};
const fmtClock = (mins) => {
  const h = Math.floor(mins / 60) % 24;
  const m = mins % 60;
  return `${h % 12 || 12}:${String(m).padStart(2, '0')} ${h >= 12 ? 'PM' : 'AM'}`;
};
const statusLabel = (st, tr) => {
  if (!st) return null;
  if (st.state === 'open') {
    if (st.allDay) return { tone: 'open', text: tr.open24 };
    if (st.minsLeft <= 60) return { tone: 'soon', text: `${tr.closingSoon} · ${st.minsLeft} ${tr.minShort}` };
    return { tone: 'open', text: `${tr.openNow} · ${tr.closesAt} ${fmtClock(st.closesAt)}` };
  }
  if (st.temp) return { tone: 'closed', text: tr.tempClosed };
  if (st.opensAt == null) return { tone: 'closed', text: tr.closedNow };
  if (st.dayOffset === 0 && st.minsToOpen > 0 && st.minsToOpen <= 60) return { tone: 'soon', text: tr.opensSoon.replace('{n}', st.minsToOpen) };
  const when = st.dayOffset === 0 ? '' : st.dayOffset === 1 ? `${tr.tomorrow} ` : `${tr.days[st.opensDay]} `;
  return { tone: 'closed', text: `${tr.closedNow} · ${tr.opensAt} ${when}${fmtClock(st.opensAt)}` };
};
const hoursRange = (blk) => {
  const o = toMin(blk?.open);
  const c = toMin(blk?.close);
  return o == null || c == null ? '—' : o === c ? '24 h' : `${fmtClock(o)} – ${fmtClock(c)}`;
};

/* ── Discovery analytics: anonymous events (card seen / menu opened / shared / called / directions / saved) that the server
   turns into per-outlet daily counters for the owner's "Guest Discovery" page. Nothing identifies the guest. ── */
const TRACK_URL = `${BASE_URL}/analytics/events`;
const trackQueue = [];
const trackLast = new Map();
let trackTimer = null;
let trackListening = false;
let trackingOff = false;
const setTrackingOff = (v) => { trackingOff = !!v; };
function flushTrack() {
  if (trackTimer) { clearTimeout(trackTimer); trackTimer = null; }
  while (trackQueue.length) {
    const events = trackQueue.splice(0, 50);
    try { fetch(TRACK_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ events }), keepalive: true }).catch(() => {}); } catch { /* ignore */ }
  }
}
function enqueueTrack(ev, immediate) {
  trackQueue.push(ev);
  if (!trackListening) {
    trackListening = true;
    window.addEventListener('pagehide', flushTrack);
    document.addEventListener('visibilitychange', () => { if (document.hidden) flushTrack(); });
  }
  // an "open" is followed by navigation to the menu, so send it straight away instead of waiting for the timer
  if (immediate || trackQueue.length >= 20) flushTrack();
  else if (!trackTimer) trackTimer = setTimeout(flushTrack, 4000);
}
const trackBlocked = () => trackingOff || typeof window === 'undefined' || typeof fetch === 'undefined' || navigator.webdriver;
function track(tenantId, type, src, extra) {
  if (!tenantId || trackBlocked()) return;
  const key = `${tenantId}|${type}|${extra?.offerId || ''}`;
  const now = Date.now();
  if (type !== 'impression' && now - (trackLast.get(key) || 0) < 1500) return; // double-tap guard
  trackLast.set(key, now);
  enqueueTrack({ tenantId, type, ...(src ? { src } : {}), ...(extra || {}) }, type === 'open');
}
/* A directory search: which outlets the top results showed and why (name / area / category / dish). The server aggregates the phrase per
   outlet per day (no visitor id); phrases that look like phone numbers or e-mail addresses are never sent. */
const searchSent = new Map();
function trackSearch(term, hits, total) {
  if (trackBlocked()) return;
  const q = normQ(term);
  if (q.length < 2 || q.length > 40 || q.includes('@') || /\d{5,}/.test(q.replace(/\s/g, ''))) return;
  const now = Date.now();
  if (now - (searchSent.get(q) || 0) < 20000) return; // same phrase again within 20 s is not a new search
  searchSent.set(q, now);
  enqueueTrack({ type: 'search', q, hits: hits.slice(0, 12), total }, false);
}
/* An outlet counts as "seen" once per browser session, when at least half its card has been on screen. */
const SEEN_KEY = 'px_home_seen';
const seenIds = (() => { let s; try { s = new Set(JSON.parse(sessionStorage.getItem(SEEN_KEY) || '[]')); } catch { s = new Set(); } return s; })();
const markSeen = (id) => {
  if (seenIds.has(id)) return false;
  seenIds.add(id);
  try { sessionStorage.setItem(SEEN_KEY, JSON.stringify([...seenIds].slice(-200))); } catch { /* ignore */ }
  return true;
};
let imprObs = null;
const imprRef = (el) => {
  if (!el || trackingOff || typeof IntersectionObserver === 'undefined') return;
  const id = el.getAttribute('data-tid');
  if (!id || seenIds.has(id)) return;
  if (!imprObs) {
    imprObs = new IntersectionObserver((entries) => {
      for (const e of entries) {
        if (!e.isIntersecting) continue;
        imprObs.unobserve(e.target);
        const tid = e.target.getAttribute('data-tid');
        if (tid && markSeen(tid)) track(tid, 'impression');
      }
    }, { threshold: 0.5 });
  }
  imprObs.observe(el);
};
const URL_KEYS = ['q', 'type', 'service', 'area', 'offers', 'veg', 'open'];

const SERVICES = [
  { id: 'pickup', label: 'Pickup', icon: ShoppingBag },
  { id: 'reservation', label: 'Reserve', icon: CalendarCheck },
  { id: 'waitlist', label: 'Waitlist', icon: Clock },
];


/* ── Location helpers: area filter, Google Maps embed + directions, distance ── */
const areaOf = (t) => String(t?.address?.area || t?.address?.city || '').trim();
const hasCoords = (t) => Number.isFinite(Number(t?.address?.lat)) && Number.isFinite(Number(t?.address?.lng)) && t?.address?.lat !== null && t?.address?.lng !== null && t?.address?.lat !== '';
const addressLine = (t) => [t?.address?.street, t?.address?.area, t?.address?.city, [t?.address?.state, t?.address?.pincode].filter(Boolean).join(' ')].map((x) => String(x || '').trim()).filter(Boolean).join(', ');
const mapQuery = (t) => (hasCoords(t) ? `${Number(t.address.lat)},${Number(t.address.lng)}` : [t?.name, addressLine(t)].filter(Boolean).join(', '));
const embedUrl = (t) => `https://www.google.com/maps?q=${encodeURIComponent(mapQuery(t))}&z=16&output=embed`;
const directionsUrl = (t) => `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(mapQuery(t))}&travelmode=driving`;
const openMapUrl = (t) => (t?.address?.mapsUrl && /^https:\/\//i.test(t.address.mapsUrl) ? t.address.mapsUrl : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(mapQuery(t))}`);
const hasPlace = (t) => hasCoords(t) || !!addressLine(t);
const distanceKm = (pos, t) => {
  if (!pos || !hasCoords(t)) return null;
  const R = 6371; const rad = (d) => (d * Math.PI) / 180;
  const dLat = rad(Number(t.address.lat) - pos.lat); const dLng = rad(Number(t.address.lng) - pos.lng);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(rad(pos.lat)) * Math.cos(rad(Number(t.address.lat))) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(a)));
};
const fmtKm = (km) => {
  if (km == null || !Number.isFinite(km)) return '';
  const m = Math.max(50, Math.round(km * 10) * 100); // nearest 100 m, never below 50 m
  if (km < 1 && m < 1000) return `${m} m`; // 0.95-0.999 km used to print "1000 m"
  return `${km < 10 ? km.toFixed(1) : Math.round(km)} km`;
};

// ── Hero: 15 short, catchy lines that replace the old "Good morning" greeting ──────────────────────────────
// A new line is picked on every visit (never the same one twice in a row) and the line rotates while the guest browses.
const HERO_EN = [
  "Hungry? We've got you.",
  'Good food is one tap away.',
  'Your next favourite bite is here.',
  'Skip the queue. Savour the moment.',
  'Scan. Order. Enjoy.',
  'Cravings, meet your match.',
  "Tonight's mood: delicious.",
  'Find the table. Find the flavour.',
  'Eat well. Wait less.',
  'Where are we eating today?',
  'Fresh picks, fired up for you.',
  'Treat yourself, you deserve it.',
  'One scan away from dinner.',
  'Taste the neighbourhood.',
  'Make today a delicious one.',
];
const HERO_MR = [
  'भूक लागली? आम्ही आहोत ना!',
  'चविष्ट जेवण, फक्त एका टॅपवर.',
  'तुमची पुढची आवडती डिश इथेच.',
  'रांग नको, फक्त चव!',
  'स्कॅन करा. ऑर्डर करा. आनंद घ्या.',
  'खवय्यांसाठी खास मेजवानी.',
  'आजचा मूड: चविष्ट!',
  'टेबल शोधा, चव शोधा.',
  'मनसोक्त खा, कमी थांबा.',
  'आज जेवायला कुठे जायचं?',
  'ताजे पदार्थ, खास तुमच्यासाठी.',
  'स्वतःला द्या एक छान ट्रीट!',
  'जेवण फक्त एका स्कॅनवर.',
  'आपल्या शहराची चव चाखा.',
  'आजचा दिवस करा चविष्ट!',
];
const HERO_LAST_KEY = 'pxh_hero_last';
const HERO_EVERY_MS = 4600;
const nextHeroIndex = (avoid, n) => {
  if (n < 2) return 0;
  let i;
  do { i = Math.floor(Math.random() * n); } while (i === avoid);
  return i;
};
let heroFirst = null; // picked once per page load, so StrictMode's double render can't pick two different lines
const firstHeroIndex = () => {
  if (heroFirst !== null) return heroFirst;
  let last = -1;
  try { const raw = localStorage.getItem(HERO_LAST_KEY); const v = Number(raw); if (raw !== null && Number.isInteger(v)) last = v; } catch { /* storage blocked */ }
  heroFirst = nextHeroIndex(last, HERO_EN.length);
  try { localStorage.setItem(HERO_LAST_KEY, String(heroFirst)); } catch { /* storage blocked */ }
  return heroFirst;
};
function HeroLine({ lang }) {
  const lines = lang === 'mr' ? HERO_MR : HERO_EN;
  const [i, setI] = useState(firstHeroIndex);
  useEffect(() => {
    let reduce = false;
    try { reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch { /* old browser */ }
    if (reduce) return undefined;
    const id = setInterval(() => {
      if (document.hidden) return; // don't churn while the tab is in the background
      setI((prev) => { const n = nextHeroIndex(prev, HERO_EN.length); try { localStorage.setItem(HERO_LAST_KEY, String(n)); } catch { /* storage blocked */ } return n; });
    }, HERO_EVERY_MS);
    return () => clearInterval(id);
  }, []);
  const words = (lines[i % lines.length] || '').split(' ');
  return (
    <div>
      <h1 key={`${lang}-${i}`} className="pxh-hl" lang={lang} aria-live="off">
        {words.map((w, k) => (
          <span key={k} className="pxh-w" style={{ animationDelay: `${k * 70}ms` }}>{w}{k < words.length - 1 ? ' ' : ''}</span>
        ))}
      </h1>
      <div className="pxh-bar" aria-hidden="true"><i key={i} /></div>
    </div>
  );
}

const css = `
html,body{scrollbar-width:none;-ms-overflow-style:none}
html::-webkit-scrollbar,body::-webkit-scrollbar,*::-webkit-scrollbar{width:0;height:0;display:none}
.pxh-sort{display:inline-flex;align-items:center;gap:6px;margin-left:auto;margin-right:8px;border:1px solid rgba(211,191,162,.18);border-radius:13px;padding:0 4px 0 10px;background:rgba(255,255,255,.03);color:rgba(211,191,162,.8)}
.pxh-sort select{appearance:none;-webkit-appearance:none;border:0;background:transparent;color:rgba(255,255,255,.7);font-size:11px;font-weight:800;padding:9px 18px 9px 2px;font-family:inherit;cursor:pointer;outline:none}
.pxh-sort select:disabled{opacity:.45;cursor:not-allowed}
.pxh-sort select option{background:#141414;color:#f7f3eb}
.pxh-top{position:fixed;right:16px;bottom:calc(18px + env(safe-area-inset-bottom,0px));width:44px;height:44px;border-radius:50%;border:1px solid rgba(211,191,162,.35);background:linear-gradient(160deg,rgba(255,255,255,.1),rgba(255,255,255,.03)),#121212;color:#d3bfa2;display:grid;place-items:center;cursor:pointer;box-shadow:0 14px 34px rgba(0,0,0,.5);z-index:40;backdrop-filter:blur(10px)}
.pxh-chips{display:flex;gap:8px;overflow-x:auto;scrollbar-width:none;-webkit-overflow-scrolling:touch;padding:4px 8px 10px;margin:-4px -8px -6px}
.pxh-chips::-webkit-scrollbar{display:none}
.pxh-chips,.pxh-areas{-webkit-mask-image:linear-gradient(90deg,#000 calc(100% - 26px),transparent);mask-image:linear-gradient(90deg,#000 calc(100% - 26px),transparent);padding-right:30px}
.pxh-chip{flex:0 0 auto;display:inline-flex;align-items:center;gap:6px;border:1px solid rgba(211,191,162,.16);background:rgba(255,255,255,.03);color:rgba(255,255,255,.62);border-radius:22px;padding:8px 13px;font-size:11px;font-weight:800;cursor:pointer;transition:all .18s}
.pxh-chip.on{background:linear-gradient(135deg,#d3bfa2,#bda88a);color:#101010;border-color:transparent;box-shadow:0 6px 18px rgba(211,191,162,.18)}
.pxh-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
@media(min-width:720px){.pxh-grid{grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:14px}}
.pxh-card{position:relative;border:1px solid rgba(211,191,162,.13);border-radius:20px;background:linear-gradient(160deg,#171717,#101010);overflow:hidden;transition:transform .2s,border-color .2s,box-shadow .2s}
.pxh-card:hover{transform:translateY(-3px);border-color:rgba(211,191,162,.35);box-shadow:0 14px 34px rgba(0,0,0,.35)}
.pxh-card>button.main{display:block;width:100%;text-align:left;background:none;border:0;color:#fff;cursor:pointer;padding:14px 14px 13px;font-family:inherit}
.pxh-heart{position:absolute;top:10px;right:10px;width:30px;height:30px;border-radius:50%;border:1px solid rgba(211,191,162,.16);background:rgba(10,10,10,.55);backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;cursor:pointer;color:rgba(211,191,162,.6);padding:0;transition:all .18s}
.pxh-heart.on{color:#d3bfa2;border-color:rgba(211,191,162,.5);background:rgba(211,191,162,.14)}
.pxh-rail{display:flex;gap:14px;overflow-x:auto;scrollbar-width:none;padding:2px 1px 6px;-webkit-overflow-scrolling:touch}
.pxh-rail::-webkit-scrollbar{display:none}
.pxh-bubble{flex:0 0 auto;width:64px;display:flex;flex-direction:column;align-items:center;gap:6px;background:none;border:0;color:rgba(255,255,255,.7);cursor:pointer;font-family:inherit;padding:0}
.pxh-ring{width:58px;height:58px;border-radius:50%;padding:2px;background:conic-gradient(from 210deg,#d3bfa2,#8a704d,#d3bfa2);display:flex}
.pxh-ring>div{flex:1;border-radius:50%;background:#f7f3eb;display:flex;align-items:center;justify-content:center;overflow:hidden;border:2px solid #0e0e0e}
.pxh-areas{display:flex;gap:8px;overflow-x:auto;scrollbar-width:none;-webkit-overflow-scrolling:touch;padding:2px 8px 4px;margin:0 -8px}
.pxh-areas::-webkit-scrollbar{display:none}
.pxh-area{flex:0 0 auto;display:inline-flex;align-items:center;gap:7px;border:1px solid rgba(211,191,162,.14);background:transparent;color:rgba(255,255,255,.6);border-radius:12px;padding:7px 11px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit;transition:all .18s}
.pxh-area b{font-size:9.5px;font-weight:900;color:rgba(211,191,162,.7);background:rgba(211,191,162,.1);border-radius:8px;padding:1px 6px}
.pxh-area.on{border-color:rgba(211,191,162,.55);background:rgba(211,191,162,.12);color:#f7f3eb}
.pxh-seg{display:inline-flex;border:1px solid rgba(211,191,162,.18);border-radius:13px;padding:3px;background:rgba(255,255,255,.03)}
.pxh-seg button{display:inline-flex;align-items:center;gap:6px;border:0;background:transparent;color:rgba(255,255,255,.55);font-size:11px;font-weight:800;padding:7px 12px;border-radius:10px;cursor:pointer;font-family:inherit}
.pxh-seg button.on{background:linear-gradient(135deg,#d3bfa2,#bda88a);color:#101010}
.pxh-sticky{position:sticky;top:0;z-index:60;margin:calc(-14px - env(safe-area-inset-top,0px)) -16px 0;padding:calc(10px + env(safe-area-inset-top,0px)) 16px 10px;background:rgba(14,14,14,.82);-webkit-backdrop-filter:blur(14px) saturate(1.2);backdrop-filter:blur(14px) saturate(1.2);transition:border-color .25s,box-shadow .25s;border-bottom:1px solid transparent}
.pxh-sticky.stuck{border-bottom-color:rgba(211,191,162,.16);box-shadow:0 10px 24px rgba(0,0,0,.35)}
.pxh-nav{position:absolute;right:10px;bottom:10px;width:32px;height:32px;border-radius:11px;border:1px solid rgba(211,191,162,.25);background:rgba(211,191,162,.1);color:#d3bfa2;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0;transition:all .18s}
.pxh-nav:hover{background:rgba(211,191,162,.2)}
.pxh-mapwrap{display:grid;gap:14px;grid-template-columns:1fr}
@media(min-width:860px){.pxh-mapwrap{grid-template-columns:minmax(280px,.8fr) 1.4fr;align-items:start}.pxh-mapwrap .pxh-maplist{max-height:560px;overflow-y:auto}.pxh-mapwrap .pxh-detail{position:sticky;top:14px}}
.pxh-place{display:flex;align-items:center;gap:11px;width:100%;text-align:left;border:1px solid rgba(211,191,162,.12);background:linear-gradient(160deg,#171717,#101010);color:#fff;border-radius:16px;padding:11px 12px;cursor:pointer;font-family:inherit;transition:all .18s}
.pxh-place.on{border-color:rgba(211,191,162,.55);background:linear-gradient(160deg,rgba(211,191,162,.14),#121212)}
.pxh-btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;border-radius:13px;padding:11px 15px;font-size:12px;font-weight:900;cursor:pointer;font-family:inherit;border:1px solid rgba(211,191,162,.26);background:rgba(211,191,162,.07);color:#d3bfa2;text-decoration:none;transition:all .18s}
.pxh-btn.pri{background:linear-gradient(135deg,#e2d3ba,#d3bfa2 55%,#bda88a);color:#101010;border-color:transparent;box-shadow:0 8px 20px -8px rgba(211,191,162,.55)}
.pxh-ribbon{position:absolute;top:0;left:0;z-index:2;pointer-events:none;display:inline-flex;align-items:center;gap:4px;padding:4px 11px 4px 9px;border-radius:0 0 12px 0;font-size:9px;font-weight:900;letter-spacing:1.1px;text-transform:uppercase}
.pxh-ribbon.feat{background:linear-gradient(135deg,#e2d3ba,#bda88a);color:#101010}
.pxh-ribbon.new{background:rgba(247,243,235,.08);color:#f7f3eb;border:1px solid rgba(247,243,235,.26);border-left:0;border-top:0}
.pxh-card.featured{border-color:rgba(211,191,162,.42);box-shadow:0 10px 30px -14px rgba(211,191,162,.35)}
.pxh-offerpill{display:inline-flex;align-items:center;gap:4px;padding:3px 8px;border-radius:10px;background:rgba(211,191,162,.12);border:1px solid rgba(211,191,162,.22);color:#d3bfa2;font-size:9.5px;font-weight:900;max-width:100%;overflow:hidden;white-space:nowrap}
.pxh-sec{display:flex;align-items:center;gap:6px;font-size:10px;font-weight:900;letter-spacing:1.6px;text-transform:uppercase;color:rgba(211,191,162,.75);margin:0 0 8px}
.pxh-feat{flex:0 0 auto;width:min(262px,76vw);display:block;text-align:left;border:1px solid rgba(211,191,162,.38);border-radius:20px;background:linear-gradient(150deg,rgba(211,191,162,.18),#121212 64%);color:#fff;padding:14px;cursor:pointer;font-family:inherit;transition:transform .2s,border-color .2s}
.pxh-feat:hover{transform:translateY(-2px);border-color:rgba(211,191,162,.6)}
.pxh-stats{display:flex;flex-wrap:wrap;gap:4px 14px;margin-top:10px;font-size:11px;color:rgba(255,255,255,.5)}
.pxh-stats b{color:#d3bfa2;font-weight:900}
.pxh-how{border:1px solid rgba(211,191,162,.14);border-radius:20px;padding:14px;background:rgba(255,255,255,.025)}
.pxh-how-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}
.pxh-how-step{display:flex;flex-direction:column;gap:6px;font-size:10.5px;line-height:1.45;color:rgba(255,255,255,.55)}
.pxh-how-step i{width:30px;height:30px;border-radius:10px;background:rgba(211,191,162,.12);border:1px solid rgba(211,191,162,.22);display:flex;align-items:center;justify-content:center}
.pxh-how-step b{font-size:12px;color:#f7f3eb}
.pxh-share{display:inline-flex;align-items:center;justify-content:center;margin-left:8px;width:24px;height:24px;border-radius:8px;border:1px solid rgba(211,191,162,.18);background:transparent;color:#d3bfa2;cursor:pointer;vertical-align:middle;padding:0}
.pxh-owner{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:14px;border:1px solid rgba(211,191,162,.3);border-radius:22px;padding:18px;background:linear-gradient(135deg,rgba(211,191,162,.15),#121212 72%)}
.pxh-status{display:flex;align-items:center;gap:6px;margin-top:6px;font-size:10px;font-weight:800;overflow:hidden;white-space:nowrap}
.pxh-status i{width:6px;height:6px;border-radius:50%;flex:0 0 auto;background:currentColor}
.pxh-status span{overflow:hidden;text-overflow:ellipsis}
.pxh-status i{box-sizing:border-box}
.pxh-status.open{color:#ece0c8}.pxh-status.soon{color:#d3bfa2}.pxh-status.closed{color:rgba(247,243,235,.46)}
.pxh-status.soon i{box-shadow:0 0 0 3px rgba(211,191,162,.24)}.pxh-status.closed i{background:transparent;border:1.5px solid currentColor}
.pxh-why{display:flex;align-items:center;gap:5px;margin-top:6px;font-size:10px;color:rgba(247,243,235,.62);overflow:hidden;white-space:nowrap}
.pxh-why span{overflow:hidden;text-overflow:ellipsis}.pxh-why svg{flex:0 0 auto;color:#d3bfa2}
@keyframes pxhSpin{to{transform:rotate(360deg)}}
.pxh-spin{animation:pxhSpin .9s linear infinite}
.pxh-refresh{display:inline-flex;align-items:center;gap:5px;border:0;background:transparent;color:rgba(255,255,255,.45);font-size:11px;font-family:inherit;cursor:pointer;padding:0}
.pxh-refresh:hover:not(:disabled){color:#d3bfa2}
@keyframes pxhShimmer{0%{background-position:-300px 0}100%{background-position:300px 0}}
.pxh-sk{position:relative;overflow:hidden;background:rgba(255,255,255,.05);flex:0 0 auto}
.pxh-sk::after{content:'';position:absolute;inset:0;transform:translateX(-100%);background:linear-gradient(100deg,transparent 0%,rgba(211,191,162,.13) 50%,transparent 100%);animation:pxhSweep 1.6s cubic-bezier(.4,0,.2,1) infinite;animation-delay:var(--d,0s)}
@keyframes pxhSweep{to{transform:translateX(100%)}}
.pxh-card.pxh-sk-card,.pxh-card.pxh-sk-card:hover{transform:none;box-shadow:none;border-color:rgba(211,191,162,.13);pointer-events:none}
.pxh-sk-in{animation:pxhSkIn .35s ease both}
.pxh-welcome{display:flex;align-items:center;gap:12px;margin:0 0 12px;padding:11px 10px 11px 12px;border-radius:18px;background:linear-gradient(135deg,rgba(211,191,162,.15),rgba(255,255,255,.03));border:1px solid rgba(211,191,162,.3);animation:pxhWord .5s cubic-bezier(.2,.8,.3,1) both}
.pxh-welcome-ico{flex:0 0 auto;width:38px;height:38px;border-radius:12px;display:grid;place-items:center;color:#14110c;background:linear-gradient(135deg,#e6d6b8,#b99f78)}
.pxh-welcome-txt{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}
.pxh-welcome-txt small{font-size:9px;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:rgba(211,191,162,.75)}
.pxh-welcome-txt b{font-size:14px;font-weight:700;color:#f7f3eb;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pxh-welcome .pxh-btn{flex:0 0 auto;padding:9px 12px}
.pxh-welcome-x{flex:0 0 auto;width:28px;height:28px;border-radius:50%;display:grid;place-items:center;border:0;cursor:pointer;color:rgba(247,243,235,.5);background:rgba(255,255,255,.05)}
@keyframes pxhSkIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
.pxh-hero{position:relative;padding:22px 0 14px}
.pxh-hero>*:not(.pxh-orb){position:relative;z-index:1}
.pxh-orb{position:absolute;border-radius:50%;filter:blur(46px);pointer-events:none;z-index:0;opacity:.55;animation:pxhFloat 9s ease-in-out infinite}
.pxh-orb.a{width:190px;height:190px;left:-60px;top:-34px;background:rgba(211,191,162,.22)}
.pxh-orb.b{width:150px;height:150px;right:0;top:46px;background:rgba(138,112,77,.3);animation-delay:-4.5s}
@keyframes pxhFloat{0%,100%{transform:translate(0,0)}50%{transform:translate(14px,-12px)}}
.pxh-eyebrow{display:flex;align-items:center;gap:8px;min-height:22px;font-size:11px;font-weight:800;color:rgba(211,191,162,.9)}
.pxh-eyebrow.en{letter-spacing:.14em;text-transform:uppercase}
.pxh-live{width:7px;height:7px;border-radius:50%;background:#7bd88f;flex:0 0 auto;animation:pxhLive 1.8s ease-out infinite}
@keyframes pxhLive{0%{box-shadow:0 0 0 0 rgba(123,216,143,.6)}70%,100%{box-shadow:0 0 0 7px rgba(123,216,143,0)}}
.pxh-hl{margin:10px 0 0;min-height:2.3em;color:#f7f3eb;text-align:left;font-family:Georgia,serif;font-weight:500;font-size:clamp(28px,7.4vw,44px);line-height:1.14;letter-spacing:-.01em;max-width:18em}
.pxh-hl:lang(mr){letter-spacing:0;line-height:1.3}
.pxh-w{display:inline-block;animation:pxhWord .55s cubic-bezier(.2,.8,.3,1) both}
@keyframes pxhWord{from{opacity:0;transform:translateY(14px);filter:blur(5px)}to{opacity:1;transform:none;filter:none}}
.pxh-bar{width:64px;height:3px;border-radius:3px;margin-top:12px;background:rgba(211,191,162,.18);overflow:hidden}
.pxh-bar i{display:block;height:100%;border-radius:3px;background:linear-gradient(90deg,#d3bfa2,#f1e3c6);transform-origin:left;animation:pxhBar 4.6s linear forwards}
@keyframes pxhBar{from{transform:scaleX(0)}to{transform:scaleX(1)}}
.pxh-grid>.pxh-card{animation:pxhCardIn .5s cubic-bezier(.2,.8,.3,1) both}
.pxh-grid>.pxh-card:nth-child(2){animation-delay:.05s}.pxh-grid>.pxh-card:nth-child(3){animation-delay:.1s}.pxh-grid>.pxh-card:nth-child(4){animation-delay:.15s}
.pxh-grid>.pxh-card:nth-child(5){animation-delay:.2s}.pxh-grid>.pxh-card:nth-child(n+6){animation-delay:.25s}
@keyframes pxhCardIn{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
/* ── Redesign: phone layout is one roomy row per place (avatar left, details right), compact header, full-width featured card ── */
.pxh-sticky img{max-width:112px}
.pxh-feat:only-child{width:100%}
@media(max-width:719px){
.pxh-grid{grid-template-columns:1fr;gap:10px}
.pxh-card>button.main{display:grid;grid-template-columns:56px minmax(0,1fr);column-gap:14px;align-items:start;padding:14px 48px 14px 14px}
.pxh-card>button.main>:first-child{grid-row:1/span 8}
.pxh-card>button.main>:not(:first-child){grid-column:2;min-width:0}
.pxh-card>button.main>:nth-child(2){margin-top:2px!important}
.pxh-card>button.main>div:last-of-type{padding-right:40px}
}
.pxh-card:active{transform:scale(.985)}
@media(max-width:719px){.pxh-card>button.main[style*="padding-top"]{padding-top:40px!important}}
.pxh-hint{margin-top:6px;font-size:11.5px;color:rgba(255,255,255,.42);line-height:1.5}
.pxh-made{margin:34px 0 8px;text-align:center;font-size:11px;letter-spacing:.04em;color:rgba(211,191,162,.55)}
.pxh-made i{display:inline-block;font-style:normal;color:#d98a7a;animation:pxhBeat 2.2s ease-in-out infinite}
@keyframes pxhBeat{0%,100%{transform:scale(1)}50%{transform:scale(1.25)}}
@media(prefers-reduced-motion:reduce){.pxh-made i{animation:none}}
@media(prefers-reduced-motion:reduce){.pxh-orb,.pxh-live,.pxh-w,.pxh-bar i,.pxh-grid>.pxh-card{animation:none!important}.pxh-bar{display:none}}
@media(prefers-reduced-motion:reduce){.pxh-spin{animation:none}.pxh-sk::after{animation:none;display:none}.pxh-sk-in{animation:none}.pxh-card{transition:none}}
`;

const Avatar = ({ t, size = 50, radius = 15 }) => {
  const [imgBroken, setImgBroken] = useState(false);
  // Every café gets the coffee mark (consistent, instantly recognisable); other places show their logo.
  if (isCafe(t)) {
    return (
      <div style={{ width: size, height: size, borderRadius: radius, background: 'linear-gradient(145deg,#f7f3eb,#e9dfcc)', boxShadow: 'inset 0 0 0 1px rgba(138,112,77,.18)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        <Coffee size={size * 0.46} color="#8a704d" strokeWidth={1.8} />
      </div>
    );
  }
  return (
    <div style={{ width: size, height: size, borderRadius: radius, background: '#f7f3eb', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, overflow: 'hidden' }}>
      {t.branding?.logoUrl && !imgBroken
        ? <img src={t.branding.logoUrl} alt="" onError={() => setImgBroken(true)} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        : <UtensilsCrossed size={size * 0.42} color="#8a704d" />}
    </div>
  );
};

/* Map + navigate card for one outlet (used in the Map view and in the quick sheet). */

/* A shared dish link (/?place=<outlet>&dish=<id>): the restaurant's spot on the home with the dish's 3D preview straight away. */
const DISH_L = {
  en: { menu: 'Open menu', place: 'Restaurant details', close: 'Close', half: 'Half', full: 'Full', no3d: 'No 3D preview for this dish yet', drag: 'Drag to rotate · pinch to zoom', veg: 'Veg', nonveg: 'Non-veg', gone: 'This dish is not available right now', shared: 'Shared with you', loading: 'Loading the dish…', share: 'Share', copied: 'Link copied', more: 'More 3D dishes here', viewing: 'Now viewing' },
  mr: { menu: 'मेनू उघडा', place: 'रेस्टॉरंट माहिती', close: 'बंद करा', half: 'अर्धा', full: 'पूर्ण', no3d: 'या पदार्थाचा 3D प्रीव्ह्यू अजून नाही', drag: 'फिरवण्यासाठी ओढा · झूमसाठी पिंच करा', veg: 'शाकाहारी', nonveg: 'मांसाहारी', gone: 'हा पदार्थ सध्या उपलब्ध नाही', shared: 'तुमच्यासाठी शेअर केले', loading: 'पदार्थ लोड होत आहे…', share: 'शेअर करा', copied: 'लिंक कॉपी केली', more: 'इथले आणखी 3D पदार्थ', viewing: 'सध्या पाहत आहात' },
};
function DishShare({ tenant, item, loading, lang, onClose, onMenu, onPlace, others = [], onPick }) {
  const L = DISH_L[lang] || DISH_L.en;
  const mr = lang === 'mr';
  const name = item ? ((mr && item.name_mr) || item.name) : '';
  const prices = item ? [item.priceHalf ? [L.half, item.priceHalf] : null, item.priceFull ? [L.full, item.priceFull] : null, !item.priceHalf && !item.priceFull && item.price ? ['', item.price] : null].filter(Boolean) : [];
  const ings = item && Array.isArray(item.ingredients) ? item.ingredients.filter((x) => typeof x === 'string').slice(0, 6) : [];
  const ref = useRef(null);
  const [note, setNote] = useState('');
  const noteT = useRef(null);
  useEffect(() => () => clearTimeout(noteT.current), []);
  const shareAgain = async () => {
    if (!item) return;
    const url = `${window.location.origin}/?place=${encodeURIComponent(tenant.tenantId)}&dish=${encodeURIComponent(item._id)}`;
    try {
      if (navigator.share) { await navigator.share({ title: item.name, text: `${item.name} — ${tenant.name}`, url }); fx.success(); return; }
      await navigator.clipboard.writeText(url);
      fx.success(); setNote(L.copied); clearTimeout(noteT.current); noteT.current = setTimeout(() => setNote(''), 1800);
    } catch { /* cancelled */ }
  };
  useEffect(() => { ref.current?.focus(); const k = (e) => { if (e.key === 'Escape') onClose(); }; document.addEventListener('keydown', k); return () => document.removeEventListener('keydown', k); }, [onClose]);
  useEffect(() => { if (item?.modelUrl) ensureModelViewer(); }, [item?.modelUrl]);
  return (
    <motion.div role="dialog" aria-modal="true" aria-label={name || tenant.name} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose}
      style={{ position: 'fixed', inset: 0, zIndex: 1100, background: 'rgba(0,0,0,.72)', backdropFilter: 'blur(6px)', WebkitBackdropFilter: 'blur(6px)', display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
      <motion.div ref={ref} tabIndex={-1} initial={{ y: 60 }} animate={{ y: 0 }} exit={{ y: 60 }} transition={{ type: 'spring', damping: 26, stiffness: 260 }} onClick={(e) => e.stopPropagation()}
        style={{ outline: 'none', width: 'min(520px,100%)', maxHeight: '94dvh', overflowY: 'auto', borderRadius: '26px 26px 0 0', background: 'linear-gradient(180deg,#1a1713,#0f0e0c)', border: '1px solid rgba(211,191,162,.22)', borderBottom: 0, boxShadow: '0 -20px 60px rgba(0,0,0,.6)', position: 'relative', paddingBottom: 'calc(18px + env(safe-area-inset-bottom,0px))' }}>
        <button type="button" onClick={onClose} aria-label={L.close} style={{ ...iconBtn, position: 'absolute', top: 12, right: 12, zIndex: 4, width: 36, height: 36, background: 'rgba(12,12,12,.8)' }}><X size={16} color={GOLD} /></button>
        <div style={{ padding: '18px 20px 10px' }}>
          <div style={{ fontSize: 10, fontWeight: 800, letterSpacing: mr ? 0 : '.16em', textTransform: mr ? 'none' : 'uppercase', color: 'rgba(211,191,162,.7)', display: 'flex', alignItems: 'center', gap: 6 }}><Share2 size={11} />{L.shared}</div>
          <div style={{ marginTop: 6, fontSize: 13, fontWeight: 700, color: GOLD, display: 'flex', alignItems: 'center', gap: 6 }}><MapPin size={13} />{(mr && tenant.name_mr) || tenant.name}{tenant.area ? <span style={{ opacity: .6, fontWeight: 500 }}> · {tenant.area}</span> : null}</div>
        </div>
        <div style={{ margin: '0 16px', height: 'min(46dvh,320px)', borderRadius: 20, overflow: 'hidden', position: 'relative', background: 'radial-gradient(circle at 50% 40%,#2a251d,#0b0a08)', border: '1px solid rgba(211,191,162,.14)' }}>
          {loading && <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', color: 'rgba(211,191,162,.7)', fontSize: 12 }}>{L.loading}</div>}
          {!loading && item?.modelUrl && (
            <>
              <model-viewer key={item._id} src={item.modelUrl} camera-controls auto-rotate ar ar-modes="webxr scene-viewer quick-look" shadow-intensity="1.2" exposure="0.9" style={{ width: '100%', height: '100%' }} />
              <div aria-hidden="true" style={{ position: 'absolute', bottom: 10, left: '50%', transform: 'translateX(-50%)', pointerEvents: 'none', fontSize: 10, color: 'rgba(255,255,255,.55)', whiteSpace: 'nowrap', background: 'rgba(0,0,0,.35)', padding: '4px 10px', borderRadius: 99 }}>{L.drag}</div>
            </>
          )}
          {!loading && (!item || !item.modelUrl) && (
            <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', textAlign: 'center', padding: 20, color: 'rgba(211,191,162,.6)', fontSize: 12 }}>
              <div><UtensilsCrossed size={34} strokeWidth={1.2} style={{ opacity: .6 }} /><div style={{ marginTop: 10 }}>{item ? L.no3d : L.gone}</div></div>
            </div>
          )}
        </div>
        {item && (
          <div style={{ padding: '14px 20px 0' }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
              <span aria-label={item.isVeg ? L.veg : L.nonveg} style={{ marginTop: 5, width: 14, height: 14, flexShrink: 0, border: `1.5px solid ${item.isVeg ? '#3fae5a' : '#d0463c'}`, borderRadius: 3, display: 'grid', placeItems: 'center' }}><i style={{ width: 6, height: 6, borderRadius: item.isVeg ? '50%' : 0, background: item.isVeg ? '#3fae5a' : '#d0463c', clipPath: item.isVeg ? undefined : 'polygon(50% 0,100% 100%,0 100%)' }} /></span>
              <h2 style={{ margin: 0, fontSize: 21, lineHeight: 1.2, color: '#f7f3eb', fontFamily: mr ? 'inherit' : "'Playfair Display', serif" }}>{name}</h2>
            </div>
            <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap', marginTop: 8, color: GOLD, fontWeight: 800, fontSize: 15 }}>{prices.map(([l, p]) => <span key={l + p}>{l ? `${l} ` : ''}₹{p}</span>)}</div>
            {ings.length > 0 && <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 10 }}>{ings.map((x, i) => <motion.span key={x} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .15 + i * .05 }} style={{ fontSize: 11, padding: '4px 10px', borderRadius: 99, border: '1px solid rgba(211,191,162,.2)', color: 'rgba(247,243,235,.75)' }}>{x}</motion.span>)}</div>}
          </div>
        )}
        <div style={{ display: 'flex', gap: 10, padding: '16px 20px 0' }}>
          <button type="button" className="pxh-btn" onClick={onMenu} style={{ flex: '1 1 0' }}>{L.menu} <ChevronRight size={14} /></button>
          <button type="button" className="pxh-btn ghost" onClick={onPlace} style={{ flex: '1 1 0', background: 'transparent', border: '1px solid rgba(211,191,162,.35)', color: GOLD }}>{L.place}</button>
        </div>
        {item && (
          <div style={{ padding: '10px 20px 0' }}>
            <button type="button" className="pxh-btn ghost" onClick={shareAgain} style={{ width: '100%', background: 'transparent', border: '1px dashed rgba(211,191,162,.35)', color: GOLD, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}><Share2 size={14} />{note || L.share}</button>
          </div>
        )}
        {others.length > 0 && (
          <div style={{ padding: '16px 0 0' }}>
            <div style={{ padding: '0 20px 8px', fontSize: 11, fontWeight: 800, color: 'rgba(211,191,162,.7)', letterSpacing: mr ? 0 : '.1em', textTransform: mr ? 'none' : 'uppercase' }}>{L.more}</div>
            <div style={{ display: 'flex', gap: 8, overflowX: 'auto', padding: '0 20px 4px', scrollbarWidth: 'none' }}>
              {others.map((o) => (
                <button key={o._id} type="button" onClick={() => { fx.tap?.(); onPick(o); }} style={{ flex: '0 0 auto', maxWidth: 190, padding: '8px 14px', borderRadius: 99, border: '1px solid rgba(211,191,162,.3)', background: 'rgba(211,191,162,.06)', color: '#f7f3eb', fontSize: 12, fontWeight: 700, cursor: 'pointer', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{(mr && o.name_mr) || o.name}</button>
              ))}
            </div>
          </div>
        )}
      </motion.div>
    </motion.div>
  );
}

function PlaceDetail({ t, pos, onOrder, onService, tr }) {
  const [note, setNote] = useState('');
  const km = distanceKm(pos, t);
  const flashTimer = useRef(null);
  useEffect(() => () => { if (flashTimer.current) window.clearTimeout(flashTimer.current); }, []);
  const flash = (m) => {
    setNote(m);
    if (flashTimer.current) window.clearTimeout(flashTimer.current); // a second tap used to be wiped by the first timer
    flashTimer.current = window.setTimeout(() => setNote(''), 2200);
  };
  const copy = async () => {
    try { await navigator.clipboard.writeText(`${t.name}${addressLine(t) ? ', ' + addressLine(t) : ''}`); flash(tr.addrCopied); }
    catch { flash(tr.copyNA); }
  };
  const share = async () => {
    // Share the restaurant's page on this platform (so a listing spreads through the app), with the map link in the text.
    const pageUrl = `${window.location.origin}/?place=${encodeURIComponent(t.tenantId)}`;
    const mapLine = hasPlace(t) ? `\n${openMapUrl(t)}` : '';
    const data = { title: t.name, text: `${t.name}${addressLine(t) ? ' - ' + addressLine(t) : ''}${mapLine}`, url: pageUrl };
    try {
      if (navigator.share) { await navigator.share(data); track(t.tenantId, 'share'); }
      else { await navigator.clipboard.writeText(`${data.text}\n${data.url}`); flash(tr.linkCopied); track(t.tenantId, 'share'); }
    } catch { /* cancelled */ }
  };
  const placeable = hasPlace(t);
  const rawPhone = String(t?.contact || t?.phone || '').trim();
  const callHref = rawPhone.replace(/\D/g, '').length >= 7 ? `tel:${rawPhone.replace(/[^\d+]/g, '')}` : '';
  return (
    <div className="pxh-detail" style={{ border: '1px solid rgba(211,191,162,.18)', borderRadius: 22, overflow: 'hidden', background: 'linear-gradient(160deg,#181818,#0f0f0f)' }}>
      <div style={{ position: 'relative', height: 'clamp(210px,38vw,300px)', background: 'linear-gradient(145deg,#1b1b1b,#121212)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ position: 'absolute', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, color: 'rgba(211,191,162,.45)', fontSize: 11 }}>
          <MapPin size={26} />{placeable ? tr.loadingMap : tr.noLocation}
        </div>
        {placeable && (
          <iframe key={t.tenantId} title={`Map of ${t.name}`} src={embedUrl(t)} loading="lazy" referrerPolicy="no-referrer-when-downgrade" allowFullScreen style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', border: 0, filter: 'saturate(.85) contrast(1.02)' }} />
        )}
        {km != null && <span style={{ position: 'absolute', left: 12, top: 12, padding: '5px 10px', borderRadius: 10, background: 'rgba(12,12,12,.82)', border: '1px solid rgba(211,191,162,.3)', color: GOLD, fontSize: 11, fontWeight: 900, backdropFilter: 'blur(6px)' }}>{fmtKm(km)} {tr.away}</span>}
      </div>
      <div style={{ padding: '16px 16px 18px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Avatar t={t} size={46} radius={14} />
          <div style={{ minWidth: 0, flex: 1 }}>
            <div style={{ fontSize: 16, fontWeight: 800, color: '#f7f3eb', fontFamily: 'Georgia, serif' }}>{t.name}</div>
            {areaOf(t) && <div style={{ fontSize: 11, color: 'rgba(211,191,162,.8)', fontWeight: 700, marginTop: 2 }}>{areaOf(t)}</div>}
          </div>
        </div>
        {(addressLine(t) || t.address?.landmark) && (
          <div style={{ marginTop: 12, fontSize: 12, lineHeight: 1.55, color: 'rgba(255,255,255,.62)' }}>
            {addressLine(t)}
            {t.address?.landmark && <div style={{ marginTop: 3, color: 'rgba(211,191,162,.7)' }}>{tr.nearLandmark} {t.address.landmark}</div>}
          </div>
        )}
        {t.hours && (() => {
          const lab = statusLabel(openStatus(t.hours), tr);
          const off = Array.isArray(t.hours.closedDays) ? t.hours.closedDays.filter((d) => d >= 0 && d <= 6) : [];
          return (
            <div style={{ marginTop: 12, padding: '11px 12px', borderRadius: 14, border: '1px solid rgba(211,191,162,.14)', background: 'rgba(255,255,255,.025)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 10, fontWeight: 900, letterSpacing: 1.4, textTransform: 'uppercase', color: 'rgba(211,191,162,.75)' }}><Clock size={12} /> {tr.hoursTitle || 'Hours'}</div>
              {lab && <div className={`pxh-status ${lab.tone}`} style={{ fontSize: 12, marginTop: 8 }}><i /><span>{lab.text}</span></div>}
              <div style={{ marginTop: 8, display: 'grid', gap: 4, fontSize: 11.5, color: 'rgba(255,255,255,.6)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10 }}><span>{tr.monFri}</span><span>{hoursRange(t.hours.weekday)}</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10 }}><span>{tr.satSun}</span><span>{hoursRange(t.hours.weekend)}</span></div>
                {off.length > 0 && <div style={{ color: 'rgba(247,243,235,.5)' }}>{tr.closedOn}: {off.map((d) => tr.days[d]).join(', ')}</div>}
              </div>
            </div>
          );
        })()}
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 9, marginTop: 14 }}>
          {placeable && <a className="pxh-btn pri" href={directionsUrl(t)} target="_blank" rel="noopener noreferrer" onClick={() => track(t.tenantId, 'directions')} style={{ flex: '1 1 140px' }}><Navigation size={14} /> {tr.directions}</a>}
          {onOrder && <button type="button" className="pxh-btn" onClick={() => onOrder(t)} style={{ flex: '1 1 110px' }}>{tr.openMenu} <ChevronRight size={14} /></button>}
          {callHref && <a className="pxh-btn" href={callHref} onClick={() => track(t.tenantId, 'call')} style={{ flex: '1 1 90px' }}><Phone size={14} /> {tr.call}</a>}
        </div>
        {onService && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 9, marginTop: 9 }}>
            {[['reservation', CalendarClock, tr.reserveNow], ['waitlist', Armchair, tr.joinWaitlist], ['pickup', ShoppingBag, tr.orderPickup]]
              .filter(([id]) => (t.config?.customerFeatures || {})[id] !== false)
              .map(([id, Icon, label]) => (
                <button key={id} type="button" className="pxh-btn" onClick={() => onService(t, id)} style={{ flex: '1 1 130px' }}><Icon size={14} /> {label}</button>
              ))}
          </div>
        )}
        {placeable && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 9 }}>
            <a className="pxh-btn" href={openMapUrl(t)} target="_blank" rel="noopener noreferrer" onClick={() => track(t.tenantId, 'directions')} style={{ padding: '8px 12px', fontSize: 11 }}><ExternalLink size={12} /> {tr.googleMaps}</a>
            <button type="button" className="pxh-btn" onClick={copy} style={{ padding: '8px 12px', fontSize: 11 }}><Copy size={12} /> {tr.copy}</button>
            <button type="button" className="pxh-btn" onClick={share} style={{ padding: '8px 12px', fontSize: 11 }}><Share2 size={12} /> {tr.share}</button>
            {note && <span role="status" style={{ alignSelf: 'center', fontSize: 11, color: GOLD, display: 'inline-flex', alignItems: 'center', gap: 4 }}><Check size={12} />{note}</span>}
          </div>
        )}
      </div>
    </div>
  );
}

export default function CustomerHome() {
  const navigate = useNavigate();
  const location = useLocation();
  // Last good list is cached: the page paints instantly, refreshes in the background, and still works offline.
  const [tenants, setTenants] = useState(() => normalizeTenants(readJson(CACHE_KEY, null)?.list));
  const [loading, setLoading] = useState(() => normalizeTenants(readJson(CACHE_KEY, null)?.list).length === 0);
  const [loadError, setLoadError] = useState('');
  const [fromCache, setFromCache] = useState(false);
  const [fresh, setFresh] = useState(false); // true once the list has come from the network in this visit
  const [menuLookup, setMenuLookup] = useState(() => { try { const c = JSON.parse(sessionStorage.getItem(MENU_CACHE_KEY) || 'null'); return c?.data ? buildMenuLookup(c.data) : null; } catch { return null; } });
  const menuReq = useRef(false);
  const listSig = useRef('');
  const [online, setOnline] = useState(() => (typeof navigator === 'undefined' ? true : navigator.onLine !== false));
  const [lang, setLang] = useState(() => { try { return localStorage.getItem(LANG_KEY) === 'mr' ? 'mr' : 'en'; } catch { return 'en'; } });
  // Coming back to the list returns to where you were; a first-visit tip points at the shuffle button.
  const homeRestored = useRef(false);
  useEffect(() => {
    let t; const onScroll = () => { window.clearTimeout(t); t = window.setTimeout(() => { try { sessionStorage.setItem('px_home_scroll', String(Math.round(window.scrollY))); } catch { /* ignore */ } }, 200); };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => { window.removeEventListener('scroll', onScroll); window.clearTimeout(t); };
  }, []);
  useEffect(() => {
    if (homeRestored.current || loading || !tenants.length) return;
    homeRestored.current = true;
    try { const sp = new URLSearchParams(window.location.search); if (sp.get('place')) return; const y = Number(sessionStorage.getItem('px_home_scroll')); if (y > 300) window.setTimeout(() => window.scrollTo(0, y), 250); } catch { /* ignore */ }
  }, [loading, tenants.length]);
  useEffect(() => {
    if (loading || !tenants.length) return undefined;
    let seen = true; try { seen = localStorage.getItem('px_home_tip') === '1'; } catch { /* ignore */ }
    if (seen) return undefined;
    const id = window.setTimeout(() => { if (window.scrollY < 80 && !document.hidden) { try { localStorage.setItem('px_home_tip', '1'); } catch { /* ignore */ } fx.toast(lang === 'mr' ? 'टीप: शफल बटण दाबा, आश्चर्याची निवड मिळेल' : 'Tip: tap the shuffle button for a surprise pick'); } }, 14000);
    return () => window.clearTimeout(id);
  }, [loading, tenants.length, lang]);
  // Tapping the logo in the sticky header scrolls back to the top.
  useEffect(() => {
    const img = document.querySelector('.pxh-sticky img');
    if (!img) return undefined;
    const go = () => { fx.tap?.(); window.scrollTo({ top: 0, behavior: 'smooth' }); };
    img.style.cursor = 'pointer'; img.addEventListener('click', go);
    return () => img.removeEventListener('click', go);
  }, [loading]);
  useEffect(() => {
    const prev = document.title;
    if (tenants.length) document.title = lang === 'mr' ? `Pratyeksha · ${tenants.length} ठिकाणे` : `Pratyeksha · ${tenants.length} place${tenants.length === 1 ? '' : 's'} to eat`;
    return () => { document.title = prev; };
  }, [tenants.length, lang]);
  const tr = L[lang];
  // A shared link (?type=cafe&service=pickup&area=rajarampuri&offers=1&q=...) opens exactly that view; otherwise the guest's saved filters apply.
  const [init] = useState(() => {
    let qp; try { qp = new URLSearchParams(location.search); } catch { qp = new URLSearchParams(); }
    const urlView = URL_KEYS.some((k) => qp.has(k));
    // ?notrack=1 (staff / owners checking their own listing) stops this browser from counting; ?notrack=0 turns counting back on. Audit mode never counts.
    try { if (qp.get('notrack') === '1') localStorage.setItem('px_notrack', '1'); else if (qp.get('notrack') === '0') localStorage.removeItem('px_notrack'); } catch { /* ignore */ }
    let muted = false; try { muted = localStorage.getItem('px_notrack') === '1'; } catch { /* ignore */ }
    setTrackingOff(muted || (AUDIT_ENABLED && qp.get('audit') === '1'));
    const sf = urlView ? {} : readJson(FILTERS_KEY, {});
    const type = urlView ? qp.get('type') : sf?.filter;
    const svc = urlView ? qp.get('service') : sf?.service;
    let storedArea = 'all'; try { storedArea = localStorage.getItem(AREA_KEY) || 'all'; } catch { /* ignore */ }
    return {
      urlView,
      filter: ['all', 'cafe', 'restaurant'].includes(type) ? type : 'all',
      service: null, // pickup / reserve / waitlist are common to every outlet, so there is no service filter any more
      favOnly: !urlView && sf?.favOnly === true,
      offersOnly: urlView ? qp.get('offers') === '1' : sf?.offersOnly === true,
      vegOnly: urlView ? qp.get('veg') === '1' : sf?.vegOnly === true,
      openOnly: urlView ? qp.get('open') === '1' : sf?.openOnly === true,
      query: urlView ? String(qp.get('q') || '').slice(0, 60) : '',
      audit: AUDIT_ENABLED && qp.get('audit') === '1',
      area: urlView ? String(qp.get('area') || 'all').trim().toLowerCase().slice(0, 60) || 'all' : storedArea,
    };
  });
  const [filter, setFilter] = useState(init.filter);
  const [service, setService] = useState(init.service);
  const [favOnly, setFavOnly] = useState(init.favOnly);
  const [offersOnly, setOffersOnly] = useState(init.offersOnly);
  const [vegOnly, setVegOnly] = useState(init.vegOnly);
  const [openOnly, setOpenOnly] = useState(init.openOnly);
  const [query, setQuery] = useState(init.query);
  const qNorm = normQ(query);
  const [limit, setLimit] = useState(PAGE);
  const [notification, setNotification] = useState(null);
  const [favs, setFavs] = useState(() => readList(FAV_KEY));
  const [recent, setRecent] = useState(() => readList(RECENT_KEY));
  const [lastPlace, setLastPlace] = useState(() => { try { const v = JSON.parse(localStorage.getItem('px_last_place') || 'null'); return v && v.tenantId ? v : null; } catch { return null; } });
  const [showAllOffers, setShowAllOffers] = useState(false);
  const [allOffers, setAllOffers] = useState([]);
  const [offersLoading, setOffersLoading] = useState(false);
  const [offersError, setOffersError] = useState('');
  const [scanning, setScanning] = useState(false);
  const [area, setArea] = useState(init.area);
  const [view, setView] = useState('list');
  const [sort, setSort] = useState(() => { try { return localStorage.getItem(SORT_KEY) || 'recommended'; } catch { return 'recommended'; } });
  const [guestName] = useState(readGuestFirstName);
  const [showTop, setShowTop] = useState(false);
  const [stuck, setStuck] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searches, setSearches] = useState(() => readList(SEARCHES_KEY));
  const [pos, setPos] = useState(null);
  const [nearMe, setNearMe] = useState(false);
  const [geoMsg, setGeoMsg] = useState('');
  const [mapId, setMapId] = useState(null);
  const [sheetTenant, setSheetTenant] = useState(null);
  useBackClose([[!!sheetTenant, () => setSheetTenant(null)], [showAllOffers, () => setShowAllOffers(false)], [scanning, () => setScanning(false)]]);
  const [sharedDish, setSharedDish] = useState(null); // { tenant, item|null, loading }
  const sharedHandled = useRef(false);
  const [howHidden, setHowHidden] = useState(() => { try { return localStorage.getItem(HOW_KEY) === '1'; } catch { return false; } });
  const [linkMsg, setLinkMsg] = useState('');
  const linkTimer = useRef(null);
  const auditTimer = useRef(null);
  useEffect(() => () => { clearTimeout(linkTimer.current); clearTimeout(auditTimer.current); }, []);
  const [updatedAt, setUpdatedAt] = useState(() => { const t = readJson(CACHE_KEY, null)?.t; return Number.isFinite(t) ? t : null; });
  const [, setTick] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const [pull, setPull] = useState(0);
  const [sugIdx, setSugIdx] = useState(-1);
  const [incompleteOnly, setIncompleteOnly] = useState(false);
  const [auditMsg, setAuditMsg] = useState('');
  const refreshingRef = useRef(false);
  const pullRef = useRef(0);
  const dialogOpenRef = useRef(false);
  // keep the "Updated … ago" label fresh
  useEffect(() => { const id = setInterval(() => setTick((n) => n + 1), 30000); return () => clearInterval(id); }, []);

  const canLocate = typeof navigator !== 'undefined' && !!navigator.geolocation;
  const canScan = typeof window !== 'undefined' && 'BarcodeDetector' in window && !!navigator.mediaDevices?.getUserMedia;

  const alive = useRef(true);
  useEffect(() => { alive.current = true; return () => { alive.current = false; }; }, []);
  const hadCache = useRef(tenants.length > 0);
  const menuCtrl = useRef(null);
  // The menu screen is a separate download now; fetch it quietly while the guest browses so tapping a restaurant is instant.
  useEffect(() => {
    const save = navigator.connection?.saveData;
    if (save) return undefined;
    const idle = typeof window.requestIdleCallback === 'function';
    const go = () => { import('./App.jsx').catch(() => {}); };
    const id = idle ? window.requestIdleCallback(go, { timeout: 5000 }) : setTimeout(go, 3500);
    return () => { if (idle) window.cancelIdleCallback(id); else clearTimeout(id); };
  }, []);
  useEffect(() => () => { menuCtrl.current?.abort(); }, []);

  const load = useCallback((signal, silent = false) => {
    if (!silent) { setLoading(true); setLoadError(''); }
    return axios.get(`${BASE_URL}/tenants/active`, { timeout: 10000, headers: { 'Cache-Control': 'no-cache' }, signal })
      .then((res) => {
        if (!alive.current) return;
        const list = normalizeTenants(res.data);
        const sig = JSON.stringify(list);
        const now = Date.now();
        if (sig !== listSig.current) { // an unchanged list keeps the same array: no re-filter / re-render of every card, no storage rewrite
          listSig.current = sig;
          setTenants(list);
          writeJson(CACHE_KEY, { t: now, list });
        }
        setFromCache(false);
        setFresh(true);
        setLoadError('');
        setUpdatedAt(now);
      })
      .catch((err) => {
        if (axios.isCancel(err) || !alive.current) return;
        const raw = readJson(CACHE_KEY, null);
        const cached = normalizeTenants(raw?.list);
        if (cached.length) { setTenants(cached); setFromCache(true); setLoadError(''); if (Number.isFinite(raw?.t)) setUpdatedAt(raw.t); return; }
        if (!silent) { setTenants([]); setLoadError(err?.response?.data?.error || ''); }
      })
      .finally(() => { if (!signal?.aborted && alive.current) setLoading(false); });
  }, []);

  useEffect(() => {
    const ctrl = new AbortController();
    load(ctrl.signal, hadCache.current);
    return () => ctrl.abort();
  }, [load]);

  // Menu index for category / dish search. Loaded once per visit: shortly after the list, or at once when the guest focuses the search box.
  const ensureMenu = useCallback(() => {
    if (menuReq.current) return;
    menuReq.current = true;
    try { const c = JSON.parse(sessionStorage.getItem(MENU_CACHE_KEY) || 'null'); if (c?.data && Date.now() - c.t < 10 * 60 * 1000) return; } catch { /* ignore */ }
    menuCtrl.current = new AbortController();
    axios.get(`${BASE_URL}/tenants/menu-index`, { timeout: 12000, signal: menuCtrl.current.signal })
      .then((res) => {
        if (!alive.current || !res.data || typeof res.data !== 'object') return;
        setMenuLookup(buildMenuLookup(res.data));
        try { sessionStorage.setItem(MENU_CACHE_KEY, JSON.stringify({ t: Date.now(), data: res.data })); } catch { /* ignore */ }
      })
      .catch((err) => { if (!axios.isCancel(err)) menuReq.current = false; }); // search keeps working on names / areas; try again on the next focus
  }, []);
  useEffect(() => {
    if (loading || !tenants.length) return undefined;
    // Data-saver / low-memory phones: fetch the dish index only when the guest actually uses search.
    try { if (navigator.connection?.saveData || (navigator.deviceMemory && navigator.deviceMemory <= 2)) return undefined; } catch { /* ignore */ }
    // Wait for an idle moment (or 2.5 s at most) so the dish index never competes with first paint.
    const idle = typeof window.requestIdleCallback === 'function';
    const id = idle ? window.requestIdleCallback(ensureMenu, { timeout: 2500 }) : setTimeout(ensureMenu, 2500);
    return () => { if (idle) window.cancelIdleCallback(id); else clearTimeout(id); };
  }, [loading, tenants.length, ensureMenu]);

  // Refresh when the guest comes back to the tab or the connection returns (at most once a minute), and track online state.
  useEffect(() => {
    let last = Date.now();
    const refresh = () => { if (document.hidden || Date.now() - last < 60000) return; last = Date.now(); load(undefined, true); };
    const goOnline = () => { setOnline(true); last = Date.now(); load(undefined, true); };
    const goOffline = () => setOnline(false);
    document.addEventListener('visibilitychange', refresh);
    window.addEventListener('online', goOnline);
    window.addEventListener('offline', goOffline);
    return () => {
      document.removeEventListener('visibilitychange', refresh);
      window.removeEventListener('online', goOnline);
      window.removeEventListener('offline', goOffline);
    };
  }, [load]);

  // Remember the guest's filters between visits.
  // (a visit through a shared link doesn't overwrite the guest's own saved filters)
  useEffect(() => { if (!init.urlView) writeJson(FILTERS_KEY, { filter, service, favOnly, offersOnly, vegOnly, openOnly }); }, [init.urlView, filter, service, favOnly, offersOnly, vegOnly, openOnly]);
  // Manual refresh (button + pull-down on touch screens).
  const refresh = useCallback(async () => {
    if (refreshingRef.current) return;
    refreshingRef.current = true;
    setRefreshing(true);
    try { await load(undefined, true); } finally {
      refreshingRef.current = false;
      if (alive.current) setRefreshing(false);
    }
  }, [load]);

  useEffect(() => {
    let startY = null;
    let startX = 0;
    const clear = () => { startY = null; if (pullRef.current) { pullRef.current = 0; setPull(0); } };
    const onStart = (e) => {
      if (e.touches.length !== 1 || window.scrollY > 0 || dialogOpenRef.current || refreshingRef.current) { startY = null; return; }
      startY = e.touches[0].clientY;
      startX = e.touches[0].clientX;
    };
    const onMove = (e) => {
      if (startY == null) return;
      const dy = e.touches[0].clientY - startY;
      const dx = Math.abs(e.touches[0].clientX - startX);
      if (dy <= 0 || dx > dy || window.scrollY > 0) { if (pullRef.current) { pullRef.current = 0; setPull(0); } return; }
      const p = Math.min(1, dy / 90);
      if (p >= 1 ? pullRef.current < 1 : Math.abs(p - pullRef.current) > 0.04) { pullRef.current = p; setPull(p); }
    };
    const onEnd = () => { const ready = pullRef.current >= 1; clear(); if (ready) refresh(); };
    window.addEventListener('touchstart', onStart, { passive: true });
    window.addEventListener('touchmove', onMove, { passive: true });
    window.addEventListener('touchend', onEnd, { passive: true });
    window.addEventListener('touchcancel', clear, { passive: true });
    return () => {
      window.removeEventListener('touchstart', onStart);
      window.removeEventListener('touchmove', onMove);
      window.removeEventListener('touchend', onEnd);
      window.removeEventListener('touchcancel', clear);
    };
  }, [refresh]);

  const chooseLang = (next) => { setLang(next); try { localStorage.setItem(LANG_KEY, next); } catch { /* ignore */ } fx.toast(next === 'mr' ? 'भाषा: मराठी' : 'Language: English'); };

  const offersReq = useRef(0);
  const loadAllOffers = async () => {
    // The sheet must open even if a previous request is still running: closing it mid-load and tapping the tag again used
    // to do nothing at all (the early return came before setShowAllOffers(true)).
    setShowAllOffers(true);
    const reqId = (offersReq.current += 1);
    setOffersLoading(true);
    setOffersError('');
    try {
      const res = await axios.get(`${BASE_URL}/offers/current/all?limit=500`, { timeout: 10000 });
      if (reqId !== offersReq.current) return;
      setAllOffers(Array.isArray(res.data?.offers) ? res.data.offers : []);
    } catch (err) {
      if (reqId !== offersReq.current) return;
      setAllOffers([]);
      setOffersError(err?.response?.data?.error || 'Unable to load offers.');
    } finally {
      if (reqId === offersReq.current) setOffersLoading(false);
    }
  };

  // A dismissed banner used to come straight back whenever the restaurant list reloaded (Retry, refresh). Remember the dismissal
  // for the current link; a new notification link shows again.
  const dismissedNote = useRef('');
  // Shared dish link: /?place=<outlet>&dish=<id> -> the restaurant's spot with the 3D preview of that dish.
  useEffect(() => {
    if (sharedHandled.current || !tenants.length) return undefined;
    let qp; try { qp = new URLSearchParams(location.search); } catch { return undefined; }
    const pid = qp.get('place'); const did = qp.get('dish');
    if (!pid) return undefined;
    const tenant = tenants.find((x) => x.tenantId === pid);
    sharedHandled.current = true;
    if (!tenant) return undefined;
    if (!did) { setSheetTenant(tenant); try { const u = new URL(window.location.href); u.searchParams.delete('place'); window.history.replaceState(null, '', u.pathname + (u.search || '') + u.hash); } catch { /* ignore */ } return undefined; }
    setSharedDish({ tenant, item: null, loading: true });
    // Not aborted when `tenants` refreshes (that would leave the sheet loading forever); only ignored after the page is gone.
    axios.get(`${BASE_URL}/menu/${encodeURIComponent(pid)}`, { timeout: 10000 })
      .then((r) => {
        if (!alive.current) return;
        const all = (Array.isArray(r.data) ? r.data : []).filter((m) => m && m.isAvailable !== false);
        const item = all.find((m) => String(m._id) === String(did)) || null;
        setSharedDish({ tenant, item, loading: false, all });
      })
      .catch(() => { if (alive.current) setSharedDish({ tenant, item: null, loading: false, all: [] }); });
    return undefined;
  }, [tenants, location.search]);
  const closeSharedDish = useCallback(() => {
    setSharedDish(null);
    try { const u = new URL(window.location.href); u.searchParams.delete('place'); u.searchParams.delete('dish'); window.history.replaceState(null, '', u.pathname + (u.search || '') + u.hash); } catch { /* ignore */ }
  }, []);

  const viewedPx = useRef('');
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const tenantId = params.get('tenantId');
    if (params.get('notification') === '1' && tenantId) {
      if (dismissedNote.current === location.search) return;
      // Report "viewed" once per opened notification link (analytics: reach -> delivered -> clicked -> viewed).
      const px = params.get('px');
      if (px && px.includes(':') && viewedPx.current !== px) {
        viewedPx.current = px;
        const [kind, ...rest] = px.split(':');
        const visitor = (() => { try { let v = localStorage.getItem('px_visitor'); if (!v) { v = Math.random().toString(36).slice(2) + Date.now().toString(36); localStorage.setItem('px_visitor', v); } return v; } catch { return ''; } })();
        const send = (endpoint) => axios.post(`${API_BASE_URL}/push-track`, { tenantId, kind, refId: rest.join(':'), event: 'viewed', endpoint, visitor }).catch(() => {});
        (async () => {
          let endpoint = '';
          try { const reg = await navigator.serviceWorker?.getRegistration?.(); endpoint = (await reg?.pushManager?.getSubscription?.())?.endpoint || ''; } catch { /* anonymous visitor id is used instead */ }
          send(endpoint);
        })();
      }
      const tenant = tenants.find((t) => t.tenantId === tenantId);
      setNotification(tenant ? `Update from ${tenant.name}` : 'You have a restaurant update');
    }
  }, [location.search, tenants]);

  const openTenant = (tenant, src = 'list', service = null) => {
    // Directory selection is not a QR/table scan, so no table number is attached.
    if (!tenant?.tenantId) return;
    // An open from the result list while a search is active is credited to the search (with the phrase), and the search itself is sent first.
    const fromSearch = src === 'list' && qNorm.length >= 2;
    if (fromSearch) sendSearchNow();
    track(tenant.tenantId, 'open', fromSearch ? 'search' : src, fromSearch ? { q: qNorm } : undefined);
    setRecent((prev) => {
      const next = [tenant.tenantId, ...prev.filter((id) => id !== tenant.tenantId)].slice(0, 8);
      writeList(RECENT_KEY, next);
      return next;
    });
    const svc = ['reservation', 'waitlist', 'pickup'].includes(service) ? `&service=${service}` : '';
    navigate(`/${encodeURIComponent(tenant.tenantId)}?entry=home${svc}`);
  };

  const toggleFav = (id, el) => {
    if (!favs.includes(id)) { track(id, 'save'); fx.like(el); fx.toast(lang === 'mr' ? `जतन केले · तुमच्या यादीत ${favs.length + 1}` : `Saved · ${favs.length + 1} in your list`); }
    setFavs((prev) => {
      const next = prev.includes(id) ? prev.filter((x) => x !== id) : [id, ...prev];
      writeList(FAV_KEY, next);
      return next;
    });
  };

  const minuteKey = Math.floor(Date.now() / 60000); // re-evaluates "Open now" every minute (the page re-renders every 30 s)
  const filtered = useMemo(() => {
    const q = normQ(query);
    const list = tenants.filter((t) => {
      const cafe = isCafe(t);
      if (filter === 'cafe' && !cafe) return false;
      if (filter === 'restaurant' && cafe) return false;
      if (service && (t.config?.customerFeatures || {})[service] === false) return false;
      if (favOnly && !favs.includes(t.tenantId)) return false;
      if (offersOnly && !(t.activeOffers || []).length) return false;
      if (vegOnly && t.config?.onlyVeg !== true) return false;
      if (init.audit && incompleteOnly && !listingGaps(t).length) return false;
      if (openOnly && openStatus(t.hours, minuteKey * 60000)?.state !== 'open') return false;
      if (area !== 'all' && areaOf(t).toLowerCase() !== area) return false;
      return !q || !!matchWhy(t, q, menuLookup);
    });
    // With Near me on, distance is the tie-breaker for every sort, and the sole order for "Recommended".
    const dist = (t) => (nearMe && pos ? (distanceKm(pos, t) ?? 1e9) : 0);
    if (sort === 'az') list.sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
    else if (sort === 'offers') list.sort((a, b) => ((b.activeOffers?.length || 0) - (a.activeOffers?.length || 0)) || (dist(a) - dist(b)));
    else if (sort === 'saved') list.sort((a, b) => (Number(favs.includes(b.tenantId)) - Number(favs.includes(a.tenantId))) || (dist(a) - dist(b)));
    else if (nearMe && pos) list.sort((a, b) => dist(a) - dist(b));
    else {
      // recommended: featured placements first, then outlets that are open (or have no hours on file) before ones known to be closed
      const closedRank = (t) => (openStatus(t.hours, minuteKey * 60000)?.state === 'closed' ? 1 : 0);
      list.sort((a, b) => Number(isFeatured(b)) - Number(isFeatured(a)) || closedRank(a) - closedRank(b));
    }
    return list;
  }, [tenants, filter, service, favOnly, offersOnly, vegOnly, incompleteOnly, init.audit, openOnly, minuteKey, favs, query, menuLookup, area, nearMe, pos, sort]);

  useEffect(() => {
    const onScroll = () => { setShowTop(window.scrollY > 520); setStuck(window.scrollY > 8); };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  const chooseSort = (v) => { setSort(v); try { localStorage.setItem(SORT_KEY, v); } catch { /* ignore */ } const lab = { recommended: tr.sortRec, az: tr.sortAz, offers: tr.sortOffers, saved: tr.sortSaved }[v]; if (lab) fx.toast(`${tr.sort}: ${lab}`); };
  const rememberSearch = (term) => {
    const t = String(term || '').trim();
    if (t.length < 2) return;
    const next = [t, ...searches.filter((x) => x.toLowerCase() !== t.toLowerCase())].slice(0, 5);
    setSearches(next); writeList(SEARCHES_KEY, next);
  };

  // Autocomplete: places, menu categories and dishes (with how many places serve them), then areas. Prefix matches rank first.
  const suggestions = useMemo(() => {
    const q = qNorm;
    if (!q) return [];
    const places = [];
    const areas = new Map();
    const cats = new Map();
    const dishes = new Map();
    const bump = (map, lc, raw, seen, tname) => {
      if (seen.has(lc)) return;
      seen.add(lc);
      const cur = map.get(lc) || { kind: '', text: raw, n: 0, names: [], rank: lc.startsWith(q) ? 0 : 1 };
      cur.n += 1;
      if (tname && cur.names.length < 3) cur.names.push(tname);
      map.set(lc, cur);
    };
    for (const t of tenants) {
      const name = String(t.name || '').trim();
      const ln = normQ(name);
      if (name && ln.includes(q) && ln !== q) places.push({ kind: 'place', text: name, sub: areaOf(t), cafe: isCafe(t), rank: ln.startsWith(q) ? 0 : 1 });
      const a = areaOf(t);
      const la = normQ(a);
      if (a && la.includes(q) && la !== q && !areas.has(la)) areas.set(la, { kind: 'area', text: a, rank: la.startsWith(q) ? 0 : 1 });
      const m = menuLookup?.map.get(t.tenantId);
      if (m) {
        const seenC = new Set();
        const seenD = new Set();
        for (const c of m.cats) if (c.lc.includes(q)) bump(cats, c.lc, c.raw, seenC, t.name);
        for (const d of m.dishes) if (d.lc.includes(q)) bump(dishes, d.lc, d.raw, seenD, t.name);
      }
    }
    const byRank = (x, y) => x.rank - y.rank || (y.n || 0) - (x.n || 0) || x.text.localeCompare(y.text);
    const count = (n) => `${n} ${n === 1 ? tr.place : tr.places}`;
    return [
      ...places.sort(byRank).slice(0, 4),
      ...[...cats.values()].sort(byRank).slice(0, 3).map((c) => ({ ...c, kind: 'category', sub: `${tr.sugCategory} · ${c.n === 1 ? c.names[0] : `${count(c.n)}: ${c.names.slice(0, 2).join(', ')}${c.n > 2 ? ` +${c.n - 2}` : ''}`}` })),
      ...[...dishes.values()].sort(byRank).slice(0, 3).map((c) => ({ ...c, kind: 'dish', sub: `${tr.sugDish} · ${c.n === 1 ? `${tr.servedAt} ${c.names[0]}` : `${count(c.n)}: ${c.names.slice(0, 2).join(', ')}${c.n > 2 ? ` +${c.n - 2}` : ''}`}` })),
      ...[...areas.values()].sort(byRank).slice(0, 2),
    ];
  }, [tenants, qNorm, menuLookup, tr]);
  const showSug = searchOpen && query.trim().length > 0 && suggestions.length > 0;

  // Typos / near misses: when nothing matches, offer the closest place, area, category or dish (edit distance, not a guess).
  const didYouMean = useMemo(() => {
    const q = qNorm;
    if (q.length < 3 || filtered.length > 0) return '';
    const lev = (a, b) => {
      if (Math.abs(a.length - b.length) > 3) return 9;
      let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
      for (let i = 1; i <= a.length; i++) { const cur = [i]; for (let j = 1; j <= b.length; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); prev = cur; }
      return prev[b.length];
    };
    const max = q.length <= 5 ? 1 : 2;
    let best = null;
    const consider = (raw) => {
      const text = String(raw || '').trim(); if (!text) return;
      const lc = normQ(text);
      const parts = [lc, ...lc.split(' ').filter((w) => w.length >= 3)];      // the whole phrase or any single word of it
      for (const p of parts) { const d = lev(q, p); if (d <= max && (!best || d < best.d)) best = { d, text }; }
    };
    for (const t of tenants) {
      consider(t.name); consider(areaOf(t));
      const m = menuLookup?.map.get(t.tenantId);
      if (m) { for (const c of m.cats) consider(c.raw); for (const d of m.dishes) consider(d.raw); }
    }
    return best && normQ(best.text) !== q ? best.text : '';
  }, [tenants, qNorm, menuLookup, filtered.length]);

  const [listening, setListening] = useState(false);
  const speechCtor = typeof window !== 'undefined' ? (window.SpeechRecognition || window.webkitSpeechRecognition) : null;
  const startVoice = () => {
    if (!speechCtor || listening) return;
    try {
      const rec = new speechCtor();
      rec.lang = lang === 'mr' ? 'mr-IN' : 'en-IN'; rec.interimResults = false; rec.maxAlternatives = 1;
      rec.onresult = (e) => { const text = e.results?.[0]?.[0]?.transcript; if (text) { setQuery(text.replace(/[.!?]+$/, '')); setSearchOpen(true); } };
      rec.onend = () => setListening(false); rec.onerror = () => setListening(false);
      setListening(true); rec.start();
    } catch { setListening(false); }
  };
  // The search that the current results answer: sent once the guest stops typing (and straight away when they open a result).
  const sendSearchNow = () => {
    if (qNorm.length < 2) return;
    trackSearch(qNorm, filtered.slice(0, 12).map((t) => ({ id: t.tenantId, w: matchWhy(t, qNorm, menuLookup)?.w || 'name' })), filtered.length);
  };
  useEffect(() => {
    if (qNorm.length < 2 || loading || !tenants.length) return undefined;
    const id = setTimeout(sendSearchNow, 1300);
    return () => clearTimeout(id);
  }, [qNorm, filtered, loading, tenants.length, menuLookup]); // eslint-disable-line react-hooks/exhaustive-deps
  const pickSuggestion = (text) => { setQuery(text); rememberSearch(text); setSearchOpen(false); setSugIdx(-1); };

  // Area chips are built from the real outlets (counts respect the other filters, not the area itself).
  const areaChips = useMemo(() => {
    const q = normQ(query);
    const counts = new Map();
    for (const t of tenants) {
      const a = areaOf(t); if (!a) continue;
      const cafe = isCafe(t);
      if (filter === 'cafe' && !cafe) continue;
      if (filter === 'restaurant' && cafe) continue;
      if (service && (t.config?.customerFeatures || {})[service] === false) continue;
      if (favOnly && !favs.includes(t.tenantId)) continue;
      if (offersOnly && !(t.activeOffers || []).length) continue;
      if (vegOnly && t.config?.onlyVeg !== true) continue;
      if (init.audit && incompleteOnly && !listingGaps(t).length) continue;
      if (openOnly && openStatus(t.hours, minuteKey * 60000)?.state !== 'open') continue;
      if (q && !matchWhy(t, q, menuLookup)) continue;
      const k = a.toLowerCase(); const cur = counts.get(k) || { key: k, label: a, n: 0 };
      cur.n += 1; counts.set(k, cur);
    }
    const list = [...counts.values()].sort((x, y) => y.n - x.n || x.label.localeCompare(y.label));
    if (area !== 'all' && !counts.has(area)) list.unshift({ key: area, label: area.replace(/\b\w/g, (c) => c.toUpperCase()), n: 0 });
    return list;
  }, [tenants, filter, service, favOnly, offersOnly, vegOnly, incompleteOnly, init.audit, openOnly, minuteKey, favs, query, menuLookup, area]);

  const chooseArea = (key) => { setArea(key); try { localStorage.setItem(AREA_KEY, key); } catch { /* ignore */ } };

  const geoReq = useRef(0);
  const toggleNear = () => {
    // geoMsg holds a translation KEY (not text), so the message follows the language toggle
    if (nearMe || geoMsg === 'finding') { geoReq.current += 1; setNearMe(false); setGeoMsg(''); return; }
    if (!navigator.geolocation) { setGeoMsg('locNA'); return; }
    setGeoMsg('finding');
    const reqId = (geoReq.current += 1);
    navigator.geolocation.getCurrentPosition(
      (p) => { if (reqId !== geoReq.current) return; setPos({ lat: p.coords.latitude, lng: p.coords.longitude }); setNearMe(true); setGeoMsg(''); },
      (err) => { if (reqId === geoReq.current) setGeoMsg(err?.code === 1 ? 'locDenied' : err?.code === 3 ? 'locTimeout' : 'locBusy'); },
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 120000 }
    );
  };

  // Any filter change goes back to the first page.
  useEffect(() => { setLimit(PAGE); }, [filter, service, favOnly, offersOnly, vegOnly, openOnly, incompleteOnly, query, area, nearMe, sort]);

  // Map view keeps a valid selection as filters change.
  const mapTenant = useMemo(() => filtered.find((t) => t.tenantId === mapId) || filtered[0] || null, [filtered, mapId]);

  const byId = useMemo(() => new Map(tenants.map((t) => [t.tenantId, t])), [tenants]);
  const jumpBack = useMemo(() => {
    const ids = [...recent, ...favs.filter((id) => !recent.includes(id))];
    return ids.map((id) => byId.get(id)).filter(Boolean).slice(0, 10);
  }, [recent, favs, byId]);

  const offerCards = useMemo(
    () => filtered.flatMap((t) => (t.activeOffers || []).map((o) => ({ ...o, _tenant: t }))).slice(0, 12),
    [filtered]
  );
  const totalOffers = useMemo(() => tenants.reduce((n, t) => n + (Array.isArray(t.activeOffers) ? t.activeOffers.length : 0), 0), [tenants]);

  const featuredList = useMemo(() => tenants.filter(isFeatured), [tenants]);
  const stats = useMemo(() => ({
    pickup: tenants.filter((t) => t.config?.customerFeatures?.pickup !== false).length,
    reserve: tenants.filter((t) => t.config?.customerFeatures?.reservation !== false).length,
  }), [tenants]);
  // Hidden when every outlet is flagged pure-veg (the schema default is true, so the flag may simply never have been set) - a filter that keeps everything is noise and could mislabel non-veg places.
  const anyVeg = useMemo(() => tenants.some((t) => t.config?.onlyVeg === true) && tenants.some((t) => t.config?.onlyVeg !== true), [tenants]);
  const anyHours = useMemo(() => tenants.some((t) => openStatus(t.hours, minuteKey * 60000)), [tenants, minuteKey]);
  const openCount = useMemo(() => tenants.filter((t) => openStatus(t.hours, minuteKey * 60000)?.state === 'open').length, [tenants, minuteKey]);
  // A saved Offers / Pure-veg filter that no longer matches anything would show an empty list with no visible chip to turn off.
  useEffect(() => {
    // Only judge a saved filter against live data: an older cached list (no hours / offers yet) must not wipe the guest's choice.
    if (loading || !fresh || !tenants.length) return;
    if (offersOnly && totalOffers === 0) setOffersOnly(false);
    if (vegOnly && !anyVeg) setVegOnly(false);
    if (openOnly && !anyHours) setOpenOnly(false);
  }, [loading, fresh, tenants.length, offersOnly, vegOnly, openOnly, totalOffers, anyVeg, anyHours]);

  const surprise = () => {
    if (!filtered.length) return;
    openTenant(filtered[Math.floor(Math.random() * filtered.length)], 'surprise');
  };

  const hour = new Date().getHours();
  const greeting = hour < 12 ? tr.morning : hour < 17 ? tr.afternoon : tr.evening;
  const greetingLine = guestName ? `${greeting}, ${guestName}` : greeting;
  const visible = filtered.slice(0, limit);
  const resetFilters = () => { setFilter('all'); setService(null); setFavOnly(false); setOffersOnly(false); setVegOnly(false); setOpenOnly(false); setIncompleteOnly(false); setQuery(''); chooseArea('all'); };
  const hasFilters = filter !== 'all' || service || favOnly || offersOnly || vegOnly || openOnly || incompleteOnly || query || area !== 'all';
  const hasMore = filtered.length > limit;
  const showFeatured = !loading && !hasFilters && view === 'list' && featuredList.length > 0;
  const showHow = !howHidden && !loading && tenants.length > 0 && !hasFilters && !recent.length && !favs.length;
  const hideHow = () => { setHowHidden(true); try { localStorage.setItem(HOW_KEY, '1'); } catch { /* ignore */ } };
  const ownerCtaOk = /^(https?:|mailto:|tel:)/i.test(OWNER_CTA_URL);
  const auditRows = useMemo(() => (init.audit ? tenants.map((t) => ({ name: t.name || t.tenantId, gaps: listingGaps(t) })).filter((r) => r.gaps.length) : []), [init.audit, tenants]);
  const copyAudit = async () => {
    const text = auditRows.length ? auditRows.map((r) => `${r.name} — ${r.gaps.join(', ')}`).join('\n') : 'All listings are complete';
    try {
      await navigator.clipboard.writeText(text);
      setAuditMsg('Report copied');
    } catch { setAuditMsg('Copy not available'); }
    clearTimeout(auditTimer.current);
    auditTimer.current = setTimeout(() => setAuditMsg(''), 2200);
  };

  // Link to exactly this filtered view - owners share it on Instagram / WhatsApp, guests land on the same list.
  const viewLink = () => {
    const p = new URLSearchParams();
    if (query.trim()) p.set('q', query.trim().slice(0, 60));
    if (filter !== 'all') p.set('type', filter);
    if (service) p.set('service', service);
    if (area !== 'all') p.set('area', area);
    if (offersOnly) p.set('offers', '1');
    if (vegOnly) p.set('veg', '1');
    if (openOnly) p.set('open', '1');
    const qs = p.toString();
    return `${window.location.origin}${window.location.pathname}${qs ? `?${qs}` : ''}`;
  };
  const shareView = async () => {
    const url = viewLink();
    try {
      if (navigator.share) { await navigator.share({ title: 'Pratyeksha', url }); return; }
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(url);
        setLinkMsg(tr.linkCopied);
        clearTimeout(linkTimer.current);
        linkTimer.current = setTimeout(() => setLinkMsg(''), 2200);
      }
    } catch { /* cancelled or blocked - nothing to do */ }
  };

  // Infinite scroll: load the next page when the sentinel nears the viewport (the "+N more" button stays as a fallback).
  const sentinelRef = useRef(null);
  useEffect(() => {
    const el = sentinelRef.current;
    if (!el || !hasMore || typeof IntersectionObserver === 'undefined') return undefined;
    const io = new IntersectionObserver((entries) => { if (entries.some((e) => e.isIntersecting)) setLimit((n) => n + PAGE); }, { rootMargin: '300px' });
    io.observe(el);
    return () => io.disconnect();
  }, [hasMore, limit, view, loading]);

  // Dialogs: Escape closes them and the page behind stops scrolling.
  const dialogOpen = !!sheetTenant || showAllOffers || scanning;
  useEffect(() => {
    if (!dialogOpen) return undefined;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (e) => { if (e.key === 'Escape') { setSheetTenant(null); setShowAllOffers(false); setScanning(false); } };
    window.addEventListener('keydown', onKey);
    return () => { document.body.style.overflow = prev; window.removeEventListener('keydown', onKey); };
  }, [dialogOpen]);
  dialogOpenRef.current = dialogOpen;
  const sheetRef = useRef(null);
  const offersRef = useRef(null);
  useFocusTrap(!!sheetTenant, sheetRef);
  useFocusTrap(showAllOffers, offersRef);

  return (
    <main style={{ minHeight: '100dvh', background: 'radial-gradient(900px 420px at 50% -10%, rgba(211,191,162,.10), transparent 60%), #0e0e0e', color: '#fff', fontFamily: 'Poppins, sans-serif', textAlign: 'left', boxShadow: '0 0 0 100vmax #0e0e0e', clipPath: 'inset(0 -100vmax)' }}>
      <style>{css}</style>
      {(pull > 0 || refreshing) && (
        <div aria-hidden="true" style={{ position: 'fixed', top: 'calc(env(safe-area-inset-top, 0px) + 10px)', left: '50%', zIndex: 1200, pointerEvents: 'none', transform: `translate(-50%, ${refreshing ? 0 : Math.round(pull * 22) - 22}px)`, opacity: refreshing ? 1 : pull, display: 'inline-flex', alignItems: 'center', gap: 7, padding: '8px 14px', borderRadius: 20, background: 'rgba(20,20,20,.94)', border: '1px solid rgba(211,191,162,.3)', color: GOLD, fontSize: 11, fontWeight: 800 }}>
          <RotateCcw size={13} className={refreshing ? 'pxh-spin' : undefined} style={refreshing ? undefined : { transform: `rotate(${Math.round(pull * 270)}deg)` }} />
          {refreshing ? tr.refreshing : pull >= 1 ? tr.releaseHint : tr.pullHint}
        </div>
      )}
      <div style={{ maxWidth: 1100, margin: '0 auto', padding: 'calc(14px + env(safe-area-inset-top, 0px)) 16px 28px' }}>

        {/* ── Top bar: install · logo · scan · offers ── */}
        <header className={`pxh-sticky${stuck ? ' stuck' : ''}`} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ background: '#f7f3eb', borderRadius: 12, padding: '5px 9px', display: 'flex', alignItems: 'center' }}>
            <img src={logo} alt="Pratyeksha" style={{ width: 132, height: 'auto', display: 'block' }} />
          </div>
          <div style={{ flex: 1 }} />
          <button type="button" onClick={() => chooseLang(lang === 'en' ? 'mr' : 'en')} aria-label={lang === 'en' ? 'मराठी' : 'English'} style={{ ...iconBtn, width: 'auto', padding: '0 12px', color: GOLD, fontSize: 11, fontWeight: 900, fontFamily: 'inherit' }}>{lang === 'en' ? 'मराठी' : 'EN'}</button>
          {canScan && (
            <button type="button" onClick={() => setScanning(true)} aria-label="Scan table QR" style={iconBtn}><ScanLine size={18} color={GOLD} /></button>
          )}
          <button type="button" onClick={loadAllOffers} aria-label="All offers" style={{ ...iconBtn, position: 'relative' }}>
            <Tag size={17} color={GOLD} />
            {totalOffers > 0 && <span style={{ position: 'absolute', top: -4, right: -4, minWidth: 17, height: 17, padding: '0 4px', borderRadius: 9, background: GOLD, color: '#101010', fontSize: 9, fontWeight: 900, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{totalOffers > 99 ? '99+' : totalOffers}</span>}
          </button>
        </header>

        {(fromCache || !online) && (
          <div role="status" style={{ marginTop: 14, padding: '9px 14px', border: '1px solid rgba(211,191,162,.18)', background: 'rgba(211,191,162,.05)', borderRadius: 14, display: 'flex', gap: 9, alignItems: 'center', fontSize: 11.5, color: 'rgba(255,255,255,.7)' }}>
            <WifiOff size={14} color={GOLD} /> {fromCache ? tr.offlineCached : tr.offline}
          </div>
        )}

        {notification && (
          <div style={{ marginTop: 14, padding: '11px 14px', border: '1px solid rgba(211,191,162,.18)', background: 'rgba(211,191,162,.06)', borderRadius: 14, display: 'flex', gap: 10, alignItems: 'center' }}>
            <img src="/notification-icon.png" alt="Pratyeksha" width={34} height={34} style={{ borderRadius: 10, flexShrink: 0, display: 'block' }} />
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,.78)', flex: 1 }}>{notification}</div>
            <button type="button" onClick={() => { dismissedNote.current = location.search; setNotification(null); }} aria-label="Dismiss" style={{ border: 0, background: 'transparent', color: GOLD, cursor: 'pointer', display: 'flex' }}><X size={15} /></button>
          </div>
        )}

        {/* ── Greeting + search ── */}
        <section className="pxh-hero">
          <span className="pxh-orb a" aria-hidden="true" />
          <span className="pxh-orb b" aria-hidden="true" />
          {/* Eyebrow: live count of places (or the time-of-day greeting + name for a returning guest), with install / sound on the right.
              The install button used to sit in the top bar, where it pushed the offers button off a 390px screen. */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
            <div className={`pxh-eyebrow ${lang === 'mr' ? 'mr' : 'en'}`}>
              {guestName
                ? <span>{greetingLine}</span>
                : (!loading && tenants.length > 0)
                  ? <><i className="pxh-live" /><span>{tenants.length} {tenants.length === 1 && lang !== 'mr' ? 'place live now' : tr.heroLive}</span></>
                  : null}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, flex: '0 0 auto' }}>
              <PwaInstallButton kind="customer" compact />
              <PrefsMenu lang={lang} /><CustomerExtras lang={lang} banner={false} topButton={false} toasts />
            </div>
          </div>
          {!guestName && <div style={{ margin: '2px 0 6px' }}><TimeGreeting lang={lang} /></div>}
          <HeroLine lang={lang} />
          {init.audit && !loading && tenants.length > 0 && (
            <div role="region" aria-label="Listing audit" style={{ marginTop: 12, padding: '10px 12px', border: '1px solid rgba(211,191,162,.4)', background: 'rgba(211,191,162,.08)', borderRadius: 14, display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 10, fontSize: 11.5, color: 'rgba(255,255,255,.8)' }}>
              <b style={{ color: '#d3bfa2' }}>Audit mode</b>
              <span>{auditRows.length} of {tenants.length} listings incomplete</span>
              <span style={{ flex: 1 }} />
              <button type="button" className={`pxh-area${incompleteOnly ? ' on' : ''}`} aria-pressed={incompleteOnly} onClick={() => setIncompleteOnly(!incompleteOnly)}>{incompleteOnly ? 'Show all' : 'Only incomplete'}</button>
              <button type="button" className="pxh-area" onClick={copyAudit}>Copy report</button>
              {auditMsg && <span role="status" style={{ color: '#d3bfa2' }}>{auditMsg}</span>}
            </div>
          )}
          <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
            <div style={{ flex: 1, position: 'relative' }}>
              <Search size={16} color="rgba(211,191,162,.55)" style={{ position: 'absolute', left: 15, top: '50%', transform: 'translateY(-50%)' }} />
              <input value={query} onFocus={() => { setSearchOpen(true); ensureMenu(); }} onBlur={() => { rememberSearch(query); setTimeout(() => setSearchOpen(false), 150); }} onKeyDown={(e) => {
                if (e.key === 'ArrowDown' && showSug) { e.preventDefault(); setSugIdx((i) => (i + 1) % suggestions.length); }
                else if (e.key === 'ArrowUp' && showSug) { e.preventDefault(); setSugIdx((i) => (i <= 0 ? suggestions.length - 1 : i - 1)); }
                else if (e.key === 'Escape' && showSug) { e.preventDefault(); setSearchOpen(false); setSugIdx(-1); }
                else if (e.key === 'Enter') {
                  if (showSug && sugIdx >= 0 && suggestions[sugIdx]) { e.preventDefault(); pickSuggestion(suggestions[sugIdx].text); } else rememberSearch(query);
                  e.currentTarget.blur();
                }
              }} onChange={(e) => { setQuery(e.target.value); setSearchOpen(true); setSugIdx(-1); }} placeholder={typeof window !== 'undefined' && window.innerWidth < 360 ? tr.searchPhShort : tr.searchPh} aria-label={tr.search}
                role="combobox" aria-expanded={showSug} aria-controls="pxh-sug" aria-autocomplete="list" aria-activedescendant={showSug && sugIdx >= 0 ? `pxh-sug-${sugIdx}` : undefined} style={{ width: '100%', boxSizing: 'border-box', textOverflow: 'ellipsis', padding: '13px 40px 13px 42px', borderRadius: 16, border: '1px solid rgba(211,191,162,.16)', background: 'rgba(255,255,255,.04)', color: '#fff', outline: 'none', fontSize: 14, fontFamily: 'inherit' }} />
              {query && <button type="button" onClick={() => setQuery('')} aria-label="Clear search" style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', border: 0, background: 'transparent', color: 'rgba(255,255,255,.4)', cursor: 'pointer', display: 'flex', padding: 4 }}><X size={15} /></button>}
              {showSug && (
                <div id="pxh-sug" role="listbox" aria-label={tr.suggestions} style={{ position: 'absolute', left: 0, right: 0, top: 'calc(100% + 6px)', zIndex: 30, borderRadius: 16, border: '1px solid rgba(211,191,162,.22)', background: '#141414', boxShadow: '0 18px 40px rgba(0,0,0,.55)', overflow: 'hidden' }}>
                  {suggestions.map((sg, i) => (
                    <button type="button" role="option" id={`pxh-sug-${i}`} key={`${sg.kind}-${sg.text}`} aria-selected={i === sugIdx} onMouseDown={(e) => e.preventDefault()} onMouseEnter={() => setSugIdx(i)} onClick={() => pickSuggestion(sg.text)} style={{ display: 'flex', alignItems: 'center', gap: 10, width: '100%', textAlign: 'left', padding: '10px 14px', border: 0, background: i === sugIdx ? 'rgba(211,191,162,.12)' : 'transparent', color: '#f7f3eb', fontSize: 13, cursor: 'pointer', fontFamily: 'inherit' }}>
                      {sg.kind === 'area' ? <MapPin size={14} color={GOLD} /> : sg.kind === 'category' ? <LayoutGrid size={14} color={GOLD} /> : sg.kind === 'dish' ? <Sparkles size={14} color={GOLD} /> : sg.cafe ? <Coffee size={14} color={GOLD} /> : <UtensilsCrossed size={14} color={GOLD} />}
                      <span style={{ flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{sg.text}</span>
                      <span style={{ fontSize: 10, color: 'rgba(255,255,255,.4)', flex: '0 0 auto' }}>{sg.kind === 'area' ? tr.sugArea : sg.sub}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
            {speechCtor && <button type="button" onClick={startVoice} aria-label={listening ? tr.listening : tr.voice} title={listening ? tr.listening : tr.voice} style={{ ...iconBtn, width: 48, height: 48, borderRadius: 16, background: listening ? 'rgba(211,191,162,.25)' : undefined }}><Mic size={18} color={GOLD} /></button>}
            <button type="button" onClick={surprise} disabled={!filtered.length} aria-label={tr.surprise} title={tr.surprise} style={{ ...iconBtn, width: 48, height: 48, borderRadius: 16, opacity: filtered.length ? 1 : .4 }}><Shuffle size={18} color={GOLD} /></button>
          </div>
        </section>

        {query.trim() && didYouMean && (
          <div role="status" style={{ marginTop: 10, fontSize: 12.5, color: 'rgba(255,255,255,.6)' }}>
            {tr.didYouMean} <button type="button" onClick={() => { setQuery(didYouMean); setSearchOpen(false); }} style={{ background: 'transparent', border: 0, color: GOLD, fontWeight: 800, fontSize: 12.5, cursor: 'pointer', textDecoration: 'underline', padding: 0 }}>{didYouMean}</button>?
          </div>
        )}

        {searchOpen && !query && searches.length > 0 && (
          <div className="pxh-areas" role="list" aria-label="Recent searches" style={{ marginTop: 10 }}>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 10, fontWeight: 800, letterSpacing: 1.4, color: 'rgba(255,255,255,.4)', textTransform: 'uppercase', flex: '0 0 auto' }}><History size={12} /> {tr.recent}</span>
            {searches.map((t) => (
              <button type="button" key={t} role="listitem" className="pxh-area" onMouseDown={(e) => e.preventDefault()} onClick={() => { setQuery(t); setSearchOpen(false); }}>{t}</button>
            ))}
            <button type="button" className="pxh-area" onMouseDown={(e) => e.preventDefault()} onClick={() => { setSearches([]); writeList(SEARCHES_KEY, []); }} aria-label={tr.clearRecent}><X size={11} /> {tr.clearRecent}</button>
          </div>
        )}

        {searchOpen && !query && menuLookup?.top.length > 0 && (
          <div className="pxh-areas" role="list" aria-label={tr.browseMenu} style={{ marginTop: 10 }}>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 10, fontWeight: 800, letterSpacing: 1.4, color: 'rgba(255,255,255,.4)', textTransform: 'uppercase', flex: '0 0 auto' }}><LayoutGrid size={12} /> {tr.browseMenu}</span>
            {menuLookup.top.map((c) => (
              <button type="button" key={c.label} role="listitem" className="pxh-area" onMouseDown={(e) => e.preventDefault()} onClick={() => { setQuery(c.label); setSearchOpen(false); }}>{c.label} <span style={{ opacity: .55 }}>{c.n}</span></button>
            ))}
          </div>
        )}

        {/* ── Welcome back: the place the guest last ordered from ── */}
        {(() => {
          if (!lastPlace) return null;
          const place = tenants.find((x) => x.tenantId === lastPlace.tenantId);
          if (!place) return null;
          return (
            <div className="pxh-welcome" role="region" aria-label={tr.welcomeBack}>
              <div className="pxh-welcome-ico"><History size={18} /></div>
              <div className="pxh-welcome-txt"><small>{tr.welcomeBack}</small><b>{(lang === 'mr' && place.name_mr) || place.name || lastPlace.name}</b></div>
              <button type="button" className="pxh-btn" onClick={() => openTenant(place, 'resume')}>{tr.pickUp} <ChevronRight size={14} /></button>
              <button type="button" className="pxh-welcome-x" aria-label={tr.dismiss} onClick={() => { setLastPlace(null); try { localStorage.removeItem('px_last_place'); } catch { /* blocked */ } }}><X size={14} /></button>
            </div>
          );
        })()}

        {/* ── Filter chips (single scrollable row) ── */}
        <div className="pxh-chips" role="toolbar" aria-label="Filters">
          <button type="button" className={`pxh-chip${filter === 'all' && !service && !favOnly && !offersOnly && !vegOnly && !openOnly ? ' on' : ''}`} onClick={resetFilters}><LayoutGrid size={13} /> {tr.all}</button>
          <button type="button" className={`pxh-chip${filter === 'cafe' ? ' on' : ''}`} onClick={() => setFilter(filter === 'cafe' ? 'all' : 'cafe')}><Coffee size={13} /> {tr.cafe}</button>
          <button type="button" className={`pxh-chip${filter === 'restaurant' ? ' on' : ''}`} onClick={() => setFilter(filter === 'restaurant' ? 'all' : 'restaurant')}><UtensilsCrossed size={13} /> {tr.dine}</button>
          <button type="button" className={`pxh-chip${favOnly ? ' on' : ''}`} onClick={() => setFavOnly(!favOnly)}><Heart size={13} fill={favOnly ? 'currentColor' : 'none'} /> {tr.saved}</button>
          {anyHours && <button type="button" className={`pxh-chip${openOnly ? ' on' : ''}`} aria-pressed={openOnly} onClick={() => setOpenOnly(!openOnly)}><Clock size={13} /> {tr.openNow}</button>}
          {totalOffers > 0 && <button type="button" className={`pxh-chip${offersOnly ? ' on' : ''}`} aria-pressed={offersOnly} onClick={() => setOffersOnly(!offersOnly)}><Tag size={13} /> {tr.offers}</button>}
          {anyVeg && <button type="button" className={`pxh-chip${vegOnly ? ' on' : ''}`} aria-pressed={vegOnly} onClick={() => setVegOnly(!vegOnly)}><Leaf size={13} /> {tr.veg}</button>}
        </div>

        {/* ── Area filter + Near me ── */}
        {(areaChips.length > 0 || canLocate) && (
          <div style={{ marginTop: 10 }}>
            <div className="pxh-areas" role="toolbar" aria-label="Areas">
              {canLocate && (
                <button type="button" className={`pxh-area${nearMe ? ' on' : ''}`} onClick={toggleNear} aria-pressed={nearMe}><Crosshair size={12} /> {tr.nearMe}</button>
              )}
              {areaChips.length > 0 && <button type="button" className={`pxh-area${area === 'all' ? ' on' : ''}`} onClick={() => chooseArea('all')}><MapPin size={12} /> {tr.allAreas}</button>}
              {areaChips.map((a) => (
                <button type="button" key={a.key} className={`pxh-area${area === a.key ? ' on' : ''}`} onClick={() => chooseArea(area === a.key ? 'all' : a.key)}>{a.label} <b>{a.n}</b></button>
              ))}
            </div>
            {geoMsg && <div role="status" style={{ marginTop: 6, fontSize: 11, color: 'rgba(211,191,162,.75)' }}>{tr[geoMsg] || ''}</div>}
          </div>
        )}

        {/* ── Featured placements ── */}
        {showFeatured && (
          <section style={{ marginTop: 18 }} aria-label={tr.featuredRail}>
            <div className="pxh-sec"><Star size={12} fill="currentColor" /> {tr.featuredRail}</div>
            <div className="pxh-rail">
              {featuredList.slice(0, 10).map((t) => {
                const best = bestOffer(t);
                const km = distanceKm(pos, t);
                return (
                  <button type="button" key={t.tenantId} className="pxh-feat" ref={imprRef} data-tid={t.tenantId} onClick={() => openTenant(t, 'featured')} aria-label={`Open ${t.name}`}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
                      <Avatar t={t} size={46} radius={14} />
                      <div style={{ minWidth: 0, flex: 1 }}>
                        <div style={{ fontSize: 14, fontWeight: 800, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.name}</div>
                        <div style={{ marginTop: 3, fontSize: 10.5, color: 'rgba(255,255,255,.5)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{[areaOf(t), km != null ? fmtKm(km) : ''].filter(Boolean).join(' · ')}</div>
                        {(() => { const l = statusLabel(openStatus(t.hours), tr); return l ? <div className={`pxh-status ${l.tone}`}><i /><span>{l.text}</span></div> : null; })()}
                      </div>
                    </div>
                    <div style={{ marginTop: 13, display: 'flex', alignItems: 'center', gap: 8 }}>
                      {best && <span className="pxh-offerpill"><Tag size={10} /> {offerValue(best)}</span>}
                      <span style={{ flex: 1 }} />
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 3, fontSize: 11, fontWeight: 900, color: GOLD }}>{tr.openMenu} <ChevronRight size={13} /></span>
                    </div>
                  </button>
                );
              })}
            </div>
          </section>
        )}

        {/* ── How it works (first-time guests only) ── */}
        {showHow && (
          <section style={{ marginTop: 18 }} aria-label={tr.howTitle}>
            <div className="pxh-how">
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
                <div className="pxh-sec" style={{ margin: 0 }}><Sparkles size={12} /> {tr.howTitle}</div>
                <button type="button" onClick={hideHow} aria-label={tr.hide} style={{ border: 0, background: 'transparent', color: 'rgba(255,255,255,.4)', fontSize: 11, fontWeight: 800, cursor: 'pointer', fontFamily: 'inherit', display: 'inline-flex', alignItems: 'center', gap: 4 }}><X size={12} /> {tr.hide}</button>
              </div>
              <div className="pxh-how-grid">
                <div className="pxh-how-step"><i><Search size={14} color={GOLD} /></i><b>{tr.how1t}</b><span>{tr.how1}</span></div>
                <div className="pxh-how-step"><i><ShoppingBag size={14} color={GOLD} /></i><b>{tr.how2t}</b><span>{tr.how2}</span></div>
                <div className="pxh-how-step"><i><Sparkles size={14} color={GOLD} /></i><b>{tr.how3t}</b><span>{tr.how3}</span></div>
              </div>
            </div>
          </section>
        )}

        {/* ── Offers rail ── */}
        {offerCards.length > 0 && (
          <section style={{ marginTop: 16 }}>
            <div className="pxh-rail">
              {offerCards.map((offer) => (
                <button type="button" key={`${offer._tenant.tenantId}-${offer._id ?? offer.title ?? ''}-${offer.type}-${offer.value ?? ''}`} onClick={() => { if (offer._id) track(offer._tenant.tenantId, 'offer', null, { offerId: String(offer._id) }); openTenant(offer._tenant, 'offers'); }} style={{ flex: '0 0 auto', minWidth: 214, maxWidth: 250, textAlign: 'left', border: '1px solid rgba(211,191,162,.2)', borderRadius: 16, background: 'linear-gradient(135deg,rgba(211,191,162,.16),rgba(211,191,162,.04) 60%,#121212)', color: '#fff', padding: '12px 13px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 10, fontFamily: 'inherit' }}>
                  {offer.imageUrl && /^https:\/\//i.test(offer.imageUrl)
                    ? <img src={offer.imageUrl} alt="" loading="lazy" width={38} height={38} style={{ width: 38, height: 38, borderRadius: 11, objectFit: 'cover', flexShrink: 0, display: 'block' }} />
                    : <Avatar t={offer._tenant} size={38} radius={11} />}
                  <div style={{ minWidth: 0, flex: 1 }}>
                    <div style={{ fontSize: 13, fontWeight: 900, color: GOLD, letterSpacing: .3 }}>{offerValue(offer)}</div>
                    {offerTerms(offer, tr) && <div style={{ marginTop: 2, fontSize: 9.5, color: 'rgba(255,255,255,.5)', lineHeight: 1.35 }}>{offerTerms(offer, tr)}</div>}
                    <div style={{ marginTop: 2, fontSize: 11, color: 'rgba(255,255,255,.6)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{offer._tenant.name}</div>
                  </div>
                  <ChevronRight size={14} color={GOLD} />
                </button>
              ))}
            </div>
          </section>
        )}

        {/* ── Jump back in (recent + saved) ── */}
        {jumpBack.length > 0 && !loading && (
          <section style={{ marginTop: 14 }}>
            <div className="pxh-rail">
              {jumpBack.map((t) => (
                <button type="button" key={t.tenantId} className="pxh-bubble" onClick={() => openTenant(t, favs.includes(t.tenantId) && !recent.includes(t.tenantId) ? 'saved' : 'recent')}>
                  <span className="pxh-ring"><div><Avatar t={t} size={50} radius={25} /></div></span>
                  <span style={{ fontSize: 10, fontWeight: 700, width: 64, textAlign: 'center', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.name}</span>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* ── Restaurants ── */}
        <section style={{ marginTop: 14 }}>
          {!loading && !loadError && filtered.length > 0 && (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10, rowGap: 8, flexWrap: 'wrap', margin: '0 0 12px' }}>
              <div style={{ fontSize: 11, color: 'rgba(255,255,255,.45)', fontWeight: 700, letterSpacing: .3 }}>
                {filtered.length} {filtered.length === 1 ? tr.place : tr.places}{area !== 'all' && areaChips.find((a) => a.key === area) ? ` ${tr.inArea} ${areaChips.find((a) => a.key === area).label}` : ''}{nearMe ? tr.nearest : ''}
                <button type="button" className="pxh-share" onClick={shareView} aria-label={tr.shareView} title={tr.shareView}><Share2 size={12} /></button>
                {linkMsg && <span role="status" style={{ marginLeft: 8, color: GOLD }}>{linkMsg}</span>}
              </div>
              <label className="pxh-sort" title={tr.sort}>
                <ArrowUpDown size={12} />
                <select aria-label={tr.sort} value={sort} onChange={(e) => chooseSort(e.target.value)}>
                  <option value="recommended">{tr.sortRec}</option>
                  <option value="az">{tr.sortAz}</option>
                  <option value="offers">{tr.sortOffers}</option>
                  <option value="saved">{tr.sortSaved}</option>
                </select>
              </label>
              <div className="pxh-seg" role="tablist" aria-label="View">
                <button type="button" role="tab" aria-selected={view === 'list'} className={view === 'list' ? 'on' : ''} onClick={() => setView('list')}><ListIcon size={13} /> {tr.list}</button>
                <button type="button" role="tab" aria-selected={view === 'map'} className={view === 'map' ? 'on' : ''} onClick={() => setView('map')}><MapIcon size={13} /> {tr.map}</button>
              </div>
            </div>
          )}
          {loading ? (
            <ListSkeleton label={tr.loadingList} />
          ) : loadError ? (
            <div style={{ border: '1px solid rgba(211,191,162,.12)', borderRadius: 20, padding: '38px 20px', textAlign: 'center', background: 'rgba(255,255,255,.02)' }}>
              <Wifi size={22} color={GOLD} />
              <div style={{ marginTop: 10, fontSize: 13, color: 'rgba(255,255,255,.6)' }}>{loadError || (online ? tr.loadFail : tr.offline)}</div>
              <button type="button" onClick={() => load()} style={{ marginTop: 14, border: '1px solid rgba(211,191,162,.28)', background: 'rgba(211,191,162,.08)', color: GOLD, borderRadius: 12, padding: '9px 16px', fontWeight: 900, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 6, fontFamily: 'inherit' }}><RotateCcw size={13} /> {tr.retry}</button>
            </div>
          ) : filtered.length === 0 ? (
            <div style={{ border: '1px solid rgba(211,191,162,.1)', borderRadius: 20, padding: '38px 20px', textAlign: 'center', background: 'rgba(255,255,255,.02)' }}>
              <Sparkles size={22} color={GOLD} />
              <div style={{ marginTop: 10, fontSize: 13, color: 'rgba(255,255,255,.55)' }}>{favOnly && !favs.length ? tr.saveHint : tr.nothing}</div>
              {!(favOnly && !favs.length) && <div className="pxh-hint">{tr.nothingHint}</div>}
              {qNorm && menuLookup?.top.length > 0 && (
                <div style={{ marginTop: 14 }}>
                  <div style={{ fontSize: 10, fontWeight: 800, letterSpacing: 1.4, color: 'rgba(255,255,255,.4)', textTransform: 'uppercase', marginBottom: 8 }}>{tr.tryMenu}</div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 7, justifyContent: 'center' }}>
                    {menuLookup.top.slice(0, 6).map((c) => <button type="button" key={c.label} className="pxh-area" onClick={() => setQuery(c.label)}>{c.label}</button>)}
                  </div>
                </div>
              )}
              {hasFilters && <button type="button" onClick={resetFilters} style={{ marginTop: 14, border: '1px solid rgba(211,191,162,.28)', background: 'rgba(211,191,162,.08)', color: GOLD, borderRadius: 12, padding: '9px 16px', fontWeight: 900, cursor: 'pointer', fontFamily: 'inherit' }}>{tr.clear}</button>}
            </div>
          ) : (
            view === 'map' && mapTenant ? (
              <div className="pxh-mapwrap">
                <div className="pxh-maplist" style={{ display: 'grid', gap: 9, alignContent: 'start', order: 2 }}>
                  {filtered.map((t) => {
                    const km = distanceKm(pos, t);
                    return (
                      <button type="button" key={t.tenantId} className={`pxh-place${mapTenant.tenantId === t.tenantId ? ' on' : ''}`} onClick={() => setMapId(t.tenantId)} aria-pressed={mapTenant.tenantId === t.tenantId}>
                        <Avatar t={t} size={40} radius={12} />
                        <span style={{ minWidth: 0, flex: 1 }}>
                          <span style={{ display: 'block', fontSize: 13, fontWeight: 800, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.name}</span>
                          <span style={{ display: 'block', marginTop: 2, fontSize: 10.5, color: 'rgba(255,255,255,.45)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{areaOf(t) || 'Location not added'}</span>
                        </span>
                        {km != null && <span style={{ fontSize: 10.5, fontWeight: 900, color: GOLD }}>{fmtKm(km)}</span>}
                      </button>
                    );
                  })}
                </div>
                <div style={{ order: 1 }}><PlaceDetail key={mapTenant.tenantId} t={mapTenant} pos={pos} onOrder={(x) => openTenant(x, 'map')} onService={(x, id) => openTenant(x, 'map', id)} tr={tr} /></div>
              </div>
            ) : (
            <>
              <div className="pxh-grid">
                {visible.map((tenant, i) => {
                  const features = tenant.config?.customerFeatures || {};
                  const isFav = favs.includes(tenant.tenantId);
                  const offers = Array.isArray(tenant.activeOffers) ? tenant.activeOffers.length : 0;
                  const best = bestOffer(tenant);
                  const featured = isFeatured(tenant);
                  const badge = featured ? 'feat' : isNew(tenant) ? 'new' : '';
                  const gaps = init.audit ? listingGaps(tenant) : [];
                  const st = statusLabel(openStatus(tenant.hours), tr);
                  const why = qNorm.length >= 2 ? matchWhy(tenant, qNorm, menuLookup) : null;
                  return (
                    <motion.div key={tenant.tenantId} className={`pxh-card${featured ? ' featured' : ''}`} ref={imprRef} data-tid={tenant.tenantId} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(i, 8) * 0.03, duration: 0.25 }} whileTap={{ scale: 0.985 }}>
                      {badge && <span className={`pxh-ribbon ${badge}`}>{badge === 'feat' ? <><Star size={9} fill="currentColor" /> {tr.featured}</> : tr.isNew}</span>}
                      <button type="button" className="main" onClick={() => openTenant(tenant)} aria-label={`Open ${tenant.name}`} style={badge ? { paddingTop: 30 } : undefined}>
                        <Avatar t={tenant} size={52} radius={16} />
                        <div style={{ marginTop: 12, fontSize: 14, fontWeight: 800, lineHeight: 1.25, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{tenant.name}</div>
                        <div style={{ marginTop: 4, display: 'flex', alignItems: 'center', gap: 4, fontSize: 10.5, color: 'rgba(255,255,255,.38)', minHeight: 14 }}>
                          {areaOf(tenant) && <><MapPin size={10} /> <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{areaOf(tenant)}{distanceKm(pos, tenant) != null ? ` · ${fmtKm(distanceKm(pos, tenant))}${distanceKm(pos, tenant) <= 2.5 ? (lang === 'mr' ? ` · ~${Math.max(1, Math.round(distanceKm(pos, tenant) * 12))} मि. चालत` : ` · ~${Math.max(1, Math.round(distanceKm(pos, tenant) * 12))} min walk`) : ''}` : ''}</span></>}
                        </div>
                        {why && !why.name && (why.dish.length > 0 || why.category.length > 0) && (
                          <div className="pxh-why"><Search size={10} /><span>{why.dish.length ? `${tr.serves}: ${why.dish.slice(0, 2).join(', ')}` : `${tr.menuCategory}: ${why.category.join(', ')}`}</span></div>
                        )}
                        {st && <div className={`pxh-status ${st.tone}`}><i /><span>{st.text}</span></div>}
                        {best && <div style={{ marginTop: 8 }}><span className="pxh-offerpill"><Tag size={10} /> {offerValue(best)}{offers > 1 ? ` +${offers - 1}` : ''}</span></div>}
                        <div style={{ marginTop: 11, display: 'flex', alignItems: 'center', gap: 9, minHeight: 24, paddingRight: hasPlace(tenant) ? 36 : 0 }}>
                          {SERVICES.map(({ id, label, icon: Icon }) => features[id] !== false && (
                            <span key={id} role="button" tabIndex={0} title={tr[id] || label} aria-label={`${tr[id] || label} - ${tenant.name}`}
                              onClick={(e) => { e.stopPropagation(); openTenant(tenant, 'list', id); }}
                              onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); e.stopPropagation(); openTenant(tenant, 'list', id); } }}
                              style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'rgba(211,191,162,.85)', padding: 6, margin: -6, borderRadius: 8, cursor: 'pointer' }}><Icon size={14} /></span>
                          ))}
                          <span style={{ flex: 1 }} />
                        </div>
                        {init.audit && (
                          <div style={{ marginTop: 8, display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                            {gaps.length === 0
                              ? <span style={{ fontSize: 9, fontWeight: 800, padding: '2px 7px', borderRadius: 8, background: 'rgba(211,191,162,.14)', color: '#ece0c8' }}>✓ Complete</span>
                              : gaps.map((g) => <span key={g} style={{ fontSize: 9, fontWeight: 800, padding: '2px 7px', borderRadius: 8, background: 'rgba(211,191,162,.14)', color: '#d3bfa2' }}>{g}</span>)}
                          </div>
                        )}
                      </button>
                      {hasPlace(tenant) && (
                        <button type="button" className="pxh-nav" onClick={() => setSheetTenant(tenant)} aria-label={`Map and directions for ${tenant.name}`}><Navigation size={14} /></button>
                      )}
                      <button type="button" className={`pxh-heart${isFav ? ' on' : ''}`} data-fx="like" onClick={(e) => toggleFav(tenant.tenantId, e.currentTarget)} aria-label={isFav ? 'Remove from saved' : 'Save'} aria-pressed={isFav}>
                        <Heart size={14} fill={isFav ? 'currentColor' : 'none'} />
                      </button>
                    </motion.div>
                  );
                })}
              </div>
              {hasMore && <div ref={sentinelRef} aria-hidden="true" style={{ height: 1 }} />}
              {hasMore && (
                <div style={{ textAlign: 'center', marginTop: 16 }}>
                  <button type="button" onClick={() => setLimit((n) => n + PAGE)} style={{ border: '1px solid rgba(211,191,162,.24)', background: 'rgba(211,191,162,.07)', color: GOLD, borderRadius: 22, padding: '10px 22px', fontWeight: 900, fontSize: 12, cursor: 'pointer', fontFamily: 'inherit' }}>
                    +{Math.min(PAGE, filtered.length - limit)} {tr.more}
                  </button>
                </div>
              )}
            </>
            )
          )}
        </section>

        {/* ── For owners: turn every guest visit into a listing enquiry ── */}
        {ownerCtaOk && !loading && (
          <section style={{ marginTop: 28 }} aria-label={tr.ownerTitle}>
            <div className="pxh-owner">
              <div style={{ flex: '1 1 240px', minWidth: 0 }}>
                <div style={{ fontFamily: 'Georgia, serif', fontSize: 20, color: '#f7f3eb' }}>{tr.ownerTitle}</div>
                <div style={{ marginTop: 6, fontSize: 12, lineHeight: 1.6, color: 'rgba(255,255,255,.6)' }}>{tr.ownerBody}</div>
              </div>
              <a className="pxh-btn pri" href={OWNER_CTA_URL} target="_blank" rel="noopener noreferrer">{tr.ownerBtn} <ChevronRight size={14} /></a>
            </div>
          </section>
        )}

        {!loading && !loadError && (
          <div className="pxh-made">{tr.madeWith.split('{h}')[0]}<i aria-label="love">♥</i>{tr.madeWith.split('{h}')[1]}</div>
        )}
      </div>

      <AnimatePresence>
        {sharedDish && (
          <DishShare key="dish-share" tenant={sharedDish.tenant} item={sharedDish.item} loading={sharedDish.loading} lang={lang} onClose={closeSharedDish}
            others={(sharedDish.all || []).filter((m) => m.modelUrl && (!sharedDish.item || m._id !== sharedDish.item._id)).slice(0, 12)}
            onPick={(o) => setSharedDish((d) => (d ? { ...d, item: o } : d))}
            onMenu={() => { const t = sharedDish.tenant; closeSharedDish(); openTenant(t, 'share'); }}
            onPlace={() => { const t = sharedDish.tenant; closeSharedDish(); setSheetTenant(t); }} />
        )}
      </AnimatePresence>
      {/* ── Map & directions sheet ── */}
      <AnimatePresence>
        {sheetTenant && (
          <motion.div role="dialog" aria-modal="true" aria-label={`Map of ${sheetTenant.name}`} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setSheetTenant(null)} style={{ position: 'fixed', inset: 0, zIndex: 1000, background: 'rgba(5,5,5,.82)', backdropFilter: 'blur(12px)', display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
            <motion.div initial={{ y: 40 }} animate={{ y: 0 }} exit={{ y: 40 }} ref={sheetRef} tabIndex={-1} onClick={(e) => e.stopPropagation()} style={{ outline: 'none', width: 'min(560px,100%)', maxHeight: '92dvh', overflowY: 'auto', borderRadius: '24px 24px 0 0', position: 'relative' }}>
              <button type="button" onClick={() => setSheetTenant(null)} aria-label="Close" style={{ ...iconBtn, position: 'absolute', top: 12, right: 12, zIndex: 3, width: 34, height: 34, background: 'rgba(12,12,12,.8)' }}><X size={16} color={GOLD} /></button>
              <PlaceDetail t={sheetTenant} pos={pos} tr={tr} onOrder={(t) => { setSheetTenant(null); openTenant(t, 'map'); }} onService={(t, id) => { setSheetTenant(null); openTenant(t, 'map', id); }} />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── All offers ── */}
      <AnimatePresence>
        {showAllOffers && (
          <motion.div role="dialog" aria-modal="true" aria-label="All offers" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowAllOffers(false)} style={{ position: 'fixed', inset: 0, zIndex: 1000, background: 'rgba(5,5,5,.82)', backdropFilter: 'blur(12px)', display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
            <motion.div initial={{ y: 40 }} animate={{ y: 0 }} exit={{ y: 40 }} ref={offersRef} tabIndex={-1} onClick={(e) => e.stopPropagation()} style={{ outline: 'none', width: 'min(900px,100%)', maxHeight: '86dvh', overflow: 'hidden', border: '1px solid rgba(211,191,162,.18)', borderBottom: 0, borderRadius: '24px 24px 0 0', background: 'linear-gradient(160deg,#181818,#0d0d0d)', display: 'flex', flexDirection: 'column' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 18px', borderBottom: '1px solid rgba(211,191,162,.1)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: GOLD, fontSize: 11, letterSpacing: 2.2, fontWeight: 900 }}><Tag size={14} /> OFFERS</div>
                <button type="button" onClick={() => setShowAllOffers(false)} aria-label="Close" style={{ width: 34, height: 34, borderRadius: 11, border: '1px solid rgba(211,191,162,.16)', background: 'rgba(255,255,255,.03)', color: GOLD, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><X size={16} /></button>
              </div>
              <div style={{ overflowY: 'auto', padding: 14, WebkitOverflowScrolling: 'touch', paddingBottom: 'calc(14px + env(safe-area-inset-bottom, 0px))' }}>
                {offersLoading ? (
                  <div style={{ minHeight: 160, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'rgba(255,255,255,.38)', fontSize: 12 }}>Loading…</div>
                ) : offersError ? (
                  <div style={{ minHeight: 140, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'rgba(255,255,255,.48)', fontSize: 12, textAlign: 'center' }}>{offersError}</div>
                ) : allOffers.length === 0 ? (
                  <div style={{ minHeight: 140, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'rgba(255,255,255,.38)', fontSize: 12, textAlign: 'center', padding: '0 24px', lineHeight: 1.6 }}>{lang === 'mr' ? 'सध्या ऑफर्स नाहीत. लवकरच पुन्हा पाहा!' : 'No offers right now. Check back soon, good deals show up here first.'}</div>
                ) : (
                  <OffersExplorer offers={allOffers} lang={lang} Avatar={Avatar} onOpen={(offer) => { const tenant = offer.tenant || {}; setShowAllOffers(false); if (offer._id) track(tenant.tenantId, 'offer', null, { offerId: String(offer._id) }); openTenant(tenant, 'offers'); }} />
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {scanning && <QrScanner onClose={() => setScanning(false)} onPath={(path) => { setScanning(false); try { if (/[?&]table=/.test(path)) sessionStorage.setItem('pratyeksha_fresh_scan', '1'); } catch { /* ignore */ } navigate(path); }} />}
      {showTop && (
        <button type="button" className="pxh-top" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} aria-label={tr.backToTop}><ArrowUp size={18} /></button>
      )}
    </main>
  );
}

const iconBtn = { width: 40, height: 40, borderRadius: 13, border: '1px solid rgba(211,191,162,.18)', background: 'rgba(255,255,255,.04)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 0, flexShrink: 0 };

/* ── In-app table QR scanner (BarcodeDetector). Only same-origin links are followed. ── */
function QrScanner({ onClose, onPath }) {
  const videoRef = useRef(null);
  const [message, setMessage] = useState('');
  const onPathRef = useRef(onPath);
  onPathRef.current = onPath;
  const dlgRef = useRef(null);
  useFocusTrap(true, dlgRef);

  useEffect(() => {
    let stream = null;
    let timer = null;
    let alive = true;
    let busy = false;
    let lastBad = '';
    (async () => {
      try {
        const detector = new window.BarcodeDetector({ formats: ['qr_code'] });
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false });
        if (!alive) { stream.getTracks().forEach((t) => t.stop()); return; }
        const video = videoRef.current;
        if (!video) { stream.getTracks().forEach((t) => t.stop()); return; } // camera light used to stay on
        video.srcObject = stream;
        await video.play().catch(() => {});
        timer = window.setInterval(async () => {
          if (busy || !video.videoWidth) return;
          busy = true;
          try {
            const codes = await detector.detect(video);
            const raw = codes?.[0]?.rawValue;
            if (raw && alive) {
              let target = null;
              try {
                const u = new URL(raw, window.location.origin);
                if (u.origin === window.location.origin) target = `${u.pathname}${u.search}${u.hash}`;
              } catch { /* not a URL */ }
              if (target) { alive = false; onPathRef.current(target); }
              else if (raw !== lastBad) { lastBad = raw; setMessage('Not a Pratyeksha table code'); }
            }
          } catch { /* transient decode error */ }
          busy = false;
        }, 350);
      } catch (err) {
        if (alive) setMessage(err?.name === 'NotAllowedError' ? 'Allow camera access to scan' : 'Camera unavailable');
      }
    })();
    return () => {
      alive = false;
      if (timer) window.clearInterval(timer);
      if (stream) stream.getTracks().forEach((t) => t.stop());
    };
  }, []);

  return (
    <div ref={dlgRef} tabIndex={-1} role="dialog" aria-modal="true" aria-label="Scan table QR" style={{ outline: 'none', position: 'fixed', inset: 0, zIndex: 1100, background: '#050505', display: 'flex', flexDirection: 'column' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: 'calc(14px + env(safe-area-inset-top, 0px)) 16px 12px', color: GOLD, fontSize: 11, letterSpacing: 2.2, fontWeight: 900 }}>
        <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}><ScanLine size={15} /> SCAN TABLE QR</span>
        <button type="button" onClick={onClose} aria-label="Close scanner" style={{ ...iconBtn, width: 36, height: 36 }}><X size={16} color={GOLD} /></button>
      </div>
      <div style={{ flex: 1, position: 'relative', overflow: 'hidden' }}>
        <video ref={videoRef} playsInline muted style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', pointerEvents: 'none' }}>
          <div style={{ width: 'min(64vw,260px)', aspectRatio: '1', borderRadius: 26, border: `2px solid ${GOLD}`, boxShadow: '0 0 0 100vmax rgba(5,5,5,.55)' }} />
        </div>
        {message && <div style={{ position: 'absolute', left: 16, right: 16, bottom: 'calc(28px + env(safe-area-inset-bottom, 0px))', textAlign: 'center', padding: '11px 14px', borderRadius: 14, background: 'rgba(15,15,15,.88)', border: '1px solid rgba(211,191,162,.25)', color: '#fff', fontSize: 12 }}>{message}</div>}
      </div>
    </div>
  );
}
